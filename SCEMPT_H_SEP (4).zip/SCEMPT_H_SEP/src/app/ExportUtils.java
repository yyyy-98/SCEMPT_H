package app;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import scemptclasses.Environnement;
import scemptclasses.Interval;
import scemptclasses.Objet;
import scemptclasses.Position;
import scemptclasses.SCEMPT_Algo;


public final class ExportUtils {
    private ExportUtils() {}
    private static final DecimalFormat DF = new DecimalFormat("0.##");

    /** Exporte tout (TXT + CSV + JSON) dans un répertoire daté /exports/SCEMPT_YYYYMMDD_HHmmss */
    public static Path exportAll(SCEMPT_Algo algo) throws IOException {
        Path dir = makeExportDir();
        Environnement E = algo.E;
        exportPlanTxt(E, dir);
        exportTFcsv(E, dir);
        exportTMcsv(E, dir);
        exportTTcsv(E, dir);
        exportJSON(E, dir);
        return dir;
    }

    /** Crée le dossier d’export. */
    public static Path makeExportDir() throws IOException {
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path dir = Paths.get("exports", "SCEMPT_" + stamp);
        Files.createDirectories(dir);
        return dir;
    }

    /* ========================= TXT ========================= */
    /** Sauvegarde le même rendu que votre PLAN FINAL (E.toString()). */
    public static void exportPlanTxt(Environnement E, Path dir) throws IOException {
        Files.writeString(dir.resolve("plan_final.txt"), E.toString(), StandardCharsets.UTF_8);
    }

    /* ========================= CSV ========================= */
    private static String fmtI(Interval I) {
        return (I == null) ? "" : "[" + DF.format(I.debut) + "," + DF.format(I.fin) + "]";
    }
    private static String csv(Object x) { return x == null ? "" : x.toString(); }
    private static String q(String s) { // échappe une valeur CSV si besoin
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    /** TF.csv : OF,TF,WP_debut,WP_fin,FP_debut,FP_fin,Machine */
    public static void exportTFcsv(Environnement E, Path dir) throws IOException {
        StringBuilder sb = new StringBuilder("OF,TF,WP_debut,WP_fin,FP_debut,FP_fin,Machine\n");
        for (Objet o : E.liste_TF) {
            String of = (o.TF != null ? o.TF.ID_ordre.toString() : "");
            String tf = (o.TF != null ? o.TF.ID_tache.toString() : "");
            Interval wp = o.WP;
            Position fp = o.FP;
            sb.append(of).append(',')
              .append(tf).append(',')
              .append(wp != null ? DF.format(wp.debut) : "").append(',')
              .append(wp != null ? DF.format(wp.fin)   : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.debut) : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.fin)   : "").append(',')
              .append(fp != null ? csv(fp.ID_resource) : "")
              .append('\n');
        }
        Files.writeString(dir.resolve("TF.csv"), sb.toString(), StandardCharsets.UTF_8);
    }

    /** TM.csv : TM,Machine,Composant,WP_debut,WP_fin,FP_debut,FP_fin,Mainteneur */
    public static void exportTMcsv(Environnement E, Path dir) throws IOException {
        StringBuilder sb = new StringBuilder("TM,Machine,Composant,WP_debut,WP_fin,FP_debut,FP_fin,Mainteneur\n");
        for (Objet o : E.liste_TM) {
            Interval wp = o.WP; Position fp = o.FP;
            sb.append(csv(o.ID)).append(',')
              .append(o.TM != null ? csv(o.TM.ID_Machine)   : "").append(',')
              .append(o.TM != null ? csv(o.TM.ID_Composant) : "").append(',')
              .append(wp != null ? DF.format(wp.debut) : "").append(',')
              .append(wp != null ? DF.format(wp.fin)   : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.debut) : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.fin)   : "").append(',')
              .append(fp != null ? csv(fp.ID_resource) : "")
              .append('\n');
        }
        Files.writeString(dir.resolve("TM.csv"), sb.toString(), StandardCharsets.UTF_8);
    }

    /** TT.csv : TT,Origine,Destination,Reason,WP_debut,WP_fin,FP_debut,FP_fin,Transporteur */
    public static void exportTTcsv(Environnement E, Path dir) throws IOException {
        StringBuilder sb = new StringBuilder("TT,Origine,Destination,Reason,WP_debut,WP_fin,FP_debut,FP_fin,Transporteur\n");
        for (Objet o : E.liste_TT) {
            Interval wp = o.WP; Position fp = o.FP;
            sb.append(csv(o.ID)).append(',')
              .append(o.TT != null ? q(o.TT.origine)     : "").append(',')
              .append(o.TT != null ? q(o.TT.destination) : "").append(',')
              .append(o.TT != null ? q(o.TT.reason)      : "").append(',')
              .append(wp != null ? DF.format(wp.debut) : "").append(',')
              .append(wp != null ? DF.format(wp.fin)   : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.debut) : "").append(',')
              .append(fp != null ? DF.format(fp.creneau.fin)   : "").append(',')
              .append(fp != null ? csv(fp.ID_resource) : "")
              .append('\n');
        }
        Files.writeString(dir.resolve("TT.csv"), sb.toString(), StandardCharsets.UTF_8);
    }

    /* ========================= JSON ========================= */
    private static String jsonI(Interval I) {
        return (I == null) ? "null"
                : "{\"start\":" + DF.format(I.debut) + ",\"end\":" + DF.format(I.fin) + "}";
    }
    private static String jsonStr(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /** plan.json : structure TF/TM/TT pour réimport. */
    public static void exportJSON(Environnement E, Path dir) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"TF\": [\n");
        for (int i = 0; i < E.liste_TF.size(); i++) {
            Objet o = E.liste_TF.get(i);
            Position fp = o.FP; Interval wp = o.WP;
            sb.append("    {")
              .append("\"of\":").append(jsonStr(o.TF.ID_ordre.toString())).append(',')
              .append("\"tf\":").append(jsonStr(o.TF.ID_tache.toString())).append(',')
              .append("\"wp\":").append(jsonI(wp)).append(',')
              .append("\"fp\":").append(fp != null
                    ? "{\"start\":" + DF.format(fp.creneau.debut) +
                      ",\"end\":"   + DF.format(fp.creneau.fin)   +
                      ",\"res\":"   + jsonStr(fp.ID_resource.toString()) + "}"
                    : "null")
              .append("}");
            if (i < E.liste_TF.size() - 1) sb.append(',');
            sb.append('\n');
        }
        sb.append("  ],\n  \"TM\": [\n");
        for (int i = 0; i < E.liste_TM.size(); i++) {
            Objet o = E.liste_TM.get(i); Position fp = o.FP; Interval wp = o.WP;
            sb.append("    {")
              .append("\"id\":").append(jsonStr(o.ID.toString())).append(',')
              .append("\"machine\":").append(jsonStr(o.TM.ID_Machine.toString())).append(',')
              .append("\"comp\":").append(jsonStr(o.TM.ID_Composant.toString())).append(',')
              .append("\"wp\":").append(jsonI(wp)).append(',')
              .append("\"fp\":").append(fp != null
                    ? "{\"start\":" + DF.format(fp.creneau.debut) +
                      ",\"end\":"   + DF.format(fp.creneau.fin)   +
                      ",\"res\":"   + jsonStr(fp.ID_resource.toString()) + "}"
                    : "null")
              .append("}");
            if (i < E.liste_TM.size() - 1) sb.append(',');
            sb.append('\n');
        }
        sb.append("  ],\n  \"TT\": [\n");
        for (int i = 0; i < E.liste_TT.size(); i++) {
            Objet o = E.liste_TT.get(i); Position fp = o.FP; Interval wp = o.WP;
            sb.append("    {")
              .append("\"id\":").append(jsonStr(o.ID.toString())).append(',')
              .append("\"orig\":").append(jsonStr(o.TT.origine)).append(',')
              .append("\"dest\":").append(jsonStr(o.TT.destination)).append(',')
              .append("\"reason\":").append(jsonStr(o.TT.reason)).append(',')
              .append("\"wp\":").append(jsonI(wp)).append(',')
              .append("\"fp\":").append(fp != null
                    ? "{\"start\":" + DF.format(fp.creneau.debut) +
                      ",\"end\":"   + DF.format(fp.creneau.fin)   +
                      ",\"res\":"   + jsonStr(fp.ID_resource.toString()) + "}"
                    : "null")
              .append("}");
            if (i < E.liste_TT.size() - 1) sb.append(',');
            sb.append('\n');
        }
        sb.append("  ]\n}\n");
        Files.writeString(dir.resolve("plan.json"), sb.toString(), StandardCharsets.UTF_8);
    }

    /* ========================= PNG (option) ========================= */
    /** Sauvegarde un composant Swing (ex: GanttChartPanel) en PNG. */
    public static void saveAsPNG(javax.swing.JComponent comp, Path file) throws IOException {
        java.awt.Dimension sz = comp.getSize();
        if (sz.width <= 0 || sz.height <= 0) {
            sz = comp.getPreferredSize();
            comp.setSize(sz);
            comp.doLayout();
        }
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(
                sz.width, sz.height, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
                            java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        comp.printAll(g2);
        g2.dispose();
        javax.imageio.ImageIO.write(img, "png", file.toFile());
    }
}
