package app;

import java.util.*;

public final class GanttRow {
    public final String name;
    public final List<GanttItem> items = new ArrayList<>();

    public GanttRow(String name) { this.name = name; }
    public void add(GanttItem it)   { items.add(it); }
    public void sortItemsByStart()  { items.sort(Comparator.comparingDouble(i -> i.start)); }
}
