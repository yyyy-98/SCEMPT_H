package app;

import java.awt.Color;

public final class GanttLegend {
    public final Color color;
    public final String label;
    public GanttLegend(Color color, String label) {
        this.color = color; this.label = label;
    }
}
