package app;

import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/**
 * Panneau de rendu des Gantt.
 * - Labels dans les barres : texte NOIR
 * - Affiche les "caps" (début / fin) sous chaque barre avec halo blanc
 * - Légende en bas
 */
public final class GanttChartPanel extends JPanel {

    private List<GanttRow> rows = Collections.emptyList();
    private List<GanttLegend> legend = Collections.emptyList();
    private double tMin = 0d, tMax = 1d;

    public void setData(final List<GanttRow> rows, double tMin, double tMax) {
        this.rows = (rows != null ? rows : Collections.emptyList());
        this.tMin = tMin;
        this.tMax = (tMax > tMin ? tMax : tMin + 1);
        revalidate();
        repaint();
    }

    public void setLegend(final List<GanttLegend> legend) {
        this.legend = (legend != null ? legend : Collections.emptyList());
        repaint();
    }

    // --- Helpers ----------------------------------------------------------------

    private static String fit(final FontMetrics fm, final String s, final int maxW) {
        if (s == null || s.isEmpty()) return "";
        if (fm.stringWidth(s) <= maxW) return s;
        final String ell = "…";
        int w = fm.stringWidth(ell);
        int end = s.length();
        while (end > 0 && w + fm.stringWidth(s.substring(0, end)) > maxW) end--;
        return end <= 0 ? ell : s.substring(0, end) + ell;
    }

    private static String cap(double v) {
        // format court sans .0
        long r = Math.round(v);
        if (Math.abs(v - r) < 1e-6) return Long.toString(r);
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    /** Texte avec halo (pastille) pour lisibilité sur fond chargé. */
    private static void drawTag(Graphics2D g2, String txt, int x, int y, int anchor,
                                int padX, int padY, float fontSize) {
        Font old = g2.getFont();
        g2.setFont(old.deriveFont(Font.PLAIN, fontSize));
        FontMetrics fm = g2.getFontMetrics();
        int tw = fm.stringWidth(txt), th = fm.getAscent();

        int bx = x, by = y - th;
        if (anchor == SwingConstants.RIGHT) bx = x - tw - padX;
        else if (anchor == SwingConstants.LEFT) bx = x + padX;
        else { // center
            bx = x - (tw / 2);
        }
        by -= padY;

        // halo (fond blanc semi-opaque)
        g2.setColor(new Color(255, 255, 255, 230));
        g2.fillRoundRect(bx - 3, by - 2, tw + 6, th + 6, 8, 8);

        // texte
        g2.setColor(Color.BLACK);
        g2.drawString(txt, bx, by + th);
        g2.setFont(old);
    }

    // --- Peinture ----------------------------------------------------------------

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (rows.isEmpty()) return;

        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            final int left = 160, right = 40, top = 30;
            final int rowH = 28, rowGap = 18;
            final int barH = 18, barArc = 10;
            final int baseY = top;

            final int innerW = Math.max(1, getWidth() - left - right);
            final double scaleX = innerW / Math.max(1e-9, (tMax - tMin));

            // Grille + axe temps
            g2.setColor(new Color(229, 231, 235));
            int tickStep = 5; // 5 unités
            for (int t = (int) Math.ceil(tMin / tickStep) * tickStep; t <= tMax; t += tickStep) {
                int x = left + (int) Math.round((t - tMin) * scaleX);
                g2.drawLine(x, 10, x, getHeight() - 40);
                g2.setColor(Color.DARK_GRAY);
                g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 10f));
                g2.drawString(Integer.toString(t), x - 6, 20);
                g2.setColor(new Color(229, 231, 235));
            }

            // Lignes
            int y = baseY;
            for (GanttRow row : rows) {
                // nom de ligne
                g2.setFont(g2.getFont().deriveFont(Font.BOLD, 12f));
                g2.setColor(Color.DARK_GRAY);
                g2.drawString(row.name, 10, y + barH + 2);

                // barres
                for (GanttItem it : row.items) {
                    int sx = left + (int) Math.round((it.start - tMin) * scaleX);
                    int ex = left + (int) Math.round((it.end   - tMin) * scaleX);
                    int bw = Math.max(1, ex - sx);

                    // fond + contour
                    Color col = (it.color != null ? it.color : new Color(180, 180, 180));
                    g2.setColor(col);
                    g2.fillRoundRect(sx, y, bw, barH, barArc, barArc);
                    g2.setColor(col.darker());
                    g2.drawRoundRect(sx, y, bw, barH, barArc, barArc);

                    // label au centre (NOIR)
                    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 12f));
                    g2.setColor(Color.BLACK);
                    FontMetrics fm = g2.getFontMetrics();
                    int maxW = Math.max(12, bw - 10);
                    String txt = fit(fm, it.label != null ? it.label : "", maxW);
                    int tx = sx + (bw - fm.stringWidth(txt)) / 2;
                    int ty = y + (barH + fm.getAscent()) / 2 - 1;
                    g2.drawString(txt, tx, ty);

                    // caps (début/fin) SOUS la barre
                    int capY = y + barH + 16;
                    drawTag(g2, cap(it.start), sx, capY, SwingConstants.RIGHT, 4, 2, 11f);
                    drawTag(g2, cap(it.end),   ex, capY, SwingConstants.LEFT, 4, 2, 11f);
                }

                y += rowH + rowGap;
            }

            // Légende
            int lx = left, ly = y + 4;
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 12f));
            for (GanttLegend lg : legend) {
                g2.setColor(lg.color != null ? lg.color : Color.GRAY);
                g2.fillRect(lx, ly, 12, 12);
                g2.setColor(Color.BLACK);
                g2.drawRect(lx, ly, 12, 12);
                g2.drawString(lg.label, lx + 18, ly + 11);
                lx += Math.max(140, 22 + g2.getFontMetrics().stringWidth(lg.label));
            }

        } finally {
            g2.dispose();
        }
    }

    @Override public Dimension getPreferredSize() {
        // largeur un peu large pour laisser scroller horizontalement
        int w = Math.max(1400, (int) Math.round((tMax - tMin) * 12) + 260);
        int h = 40 + rows.size() * (28 + 18) + 60;
        return new Dimension(w, Math.max(420, h));
    }
}
