package app;

import java.awt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.*;
import scemptclasses.SCEMPT_Algo;

public final class GanttWindow extends JFrame {

    private final GanttChartPanel chartPanel = new GanttChartPanel();
    private final SCEMPT_Algo algo; // nullable : sert si on veut aussi exporter TXT/CSV/JSON

    public GanttChartPanel getChartPanel() { return chartPanel; }

    /** Fenêtre Gantt avec barre d’outils (PNG + export données) */
    
    public GanttWindow(String title,
                       java.util.List<GanttRow> rows,
                       double tMin, double tMax,
                       java.util.List<GanttLegend> legend,
                       SCEMPT_Algo algo /* peut être null */) {
        super(title);
        this.algo = algo;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // contenu graphique
        chartPanel.setData(rows, tMin, tMax);
        chartPanel.setLegend(legend);
        JScrollPane sp = new JScrollPane(chartPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.getHorizontalScrollBar().setUnitIncrement(16);

        // barre d’outils
        JToolBar tb = new JToolBar();
        tb.setFloatable(false);

        JButton btPng = new JButton("Exporter PNG");
        btPng.addActionListener(e -> {
            try {
                doExportPngWithDialog();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Échec export PNG : " + ex.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        tb.add(btPng);

        JButton btData = new JButton("Exporter données (TXT/CSV/JSON)");
        btData.addActionListener(e -> {
            if (this.algo == null) {
                JOptionPane.showMessageDialog(this,
                        "Aucun objet SCEMPT_Algo fourni au constructeur,\n"
                      + "l’export de données n’est pas disponible.",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            try {
                Path dir = ExportUtils.exportAll(this.algo);
                JOptionPane.showMessageDialog(this,
                        "Données exportées dans :\n" + dir.toAbsolutePath(),
                        "Export terminé", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Échec export données : " + ex.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        tb.addSeparator();
        tb.add(btData);

        add(tb, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        setSize(new Dimension(1600, 900));
        setLocationByPlatform(true);
    }

    /** Sauvegarde silencieuse vers un chemin donné (utile dans des scripts/tests). */
    public void savePng(Path file) throws IOException {
        ExportUtils.saveAsPNG(chartPanel, file);
    }

    /** Petit helper pour choisir un fichier PNG et sauver. */
    private void doExportPngWithDialog() throws IOException {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Enregistrer la figure en PNG");
        fc.setSelectedFile(Paths.get(safeFileName(getTitle()) + ".png").toFile());
        int ret = fc.showSaveDialog(this);
        if (ret == JFileChooser.APPROVE_OPTION) {
            Path f = fc.getSelectedFile().toPath();
            if (!f.toString().toLowerCase().endsWith(".png")) {
                f = Paths.get(f.toString() + ".png");
            }
            ExportUtils.saveAsPNG(chartPanel, f);
            JOptionPane.showMessageDialog(this,
                    "Figure enregistrée :\n" + f.toAbsolutePath(),
                    "Export PNG", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /** Titre → nom de fichier « safe » */
    private static String safeFileName(String s) {
        if (s == null || s.isBlank()) return "gantt";
        return s.replaceAll("[^\\p{L}\\p{Nd}_\\-]+", "_")
                .replaceAll("__+", "_")
                .replaceAll("^_|_$", "");
    }
}
