package app;

import java.awt.Color;

public final class GanttItem {
    public final String label;
    public final double start;
    public final double end;
    public final Color color;
    /** Optionnel : "TF", "TT", "TM" */
    public final String kind;

    public GanttItem(String label, double start, double end, Color color) {
        this(label, start, end, color, null);
    }
    public GanttItem(String label, double start, double end, Color color, String kind) {
        this.label = label;
        this.start = start;
        this.end   = end;
        this.color = color;
        this.kind  = kind;
    }
    public double duration() { return end - start; }
}
