package app;
import java.util.*;
import java.util.stream.Collectors;
import scemptclasses.*;


public class MainSCEMPT {

    private static scemptclasses.Machine buildSimpleMachine(Identifiant machineId,
                                               Identifiant... activities) {
        scemptclasses.Machine machine = new scemptclasses.Machine(machineId, false);

        int compIdx = 0;
        for (Identifiant act : activities) {
            // composant dédié pour l'activité, avec une très grande durée de vie
            Identifiant compId = new Identifiant("C", machineId.ordre * 10 + (++compIdx));
            Composant comp = new Composant(compId, act, 10_000.0, 0.0, false);
            comp.seuil = 9_999.0; // évite toute maintenance dans l'exemple
            machine.add_Composant(comp);

            Fonction f = new Fonction();
            f.logique = LogicType.AND;
            f.add_composant(comp.ID);
            machine.add_Competence(new Competence(act, 0, 1, 1, f));
        }

        return machine;
    }

    private static void runThreeOrderFifoIllustration() {
        Identifiant FRAISAGE = new Identifiant("ACT", 1);
        Identifiant TOURNAGE = new Identifiant("ACT", 2);
        Identifiant DECOUPE  = new Identifiant("ACT", 3);
        Identifiant PERCAGE  = new Identifiant("ACT", 4);

        // Ordres de fabrication (MO)
        OF mo1 = new OF(new Identifiant("MO", 1), 2, 21);
        TacheProduction o11 = new TacheProduction(mo1.ID, new Identifiant("OP", 11), 6);
        o11.add_activite(FRAISAGE);
        TacheProduction o12 = new TacheProduction(mo1.ID, new Identifiant("OP", 12), 8);
        o12.add_activite(TOURNAGE);
        TacheProduction o13 = new TacheProduction(mo1.ID, new Identifiant("OP", 13), 5);
        o13.add_activite(PERCAGE);
        mo1.add_TF(o11); mo1.add_TF(o12); mo1.add_TF(o13);

        OF mo2 = new OF(new Identifiant("MO", 2), 1, 16);
        TacheProduction o21 = new TacheProduction(mo2.ID, new Identifiant("OP", 21), 8);
        o21.add_activite(TOURNAGE);
        TacheProduction o22 = new TacheProduction(mo2.ID, new Identifiant("OP", 22), 7);
        o22.add_activite(DECOUPE);
        mo2.add_TF(o21); mo2.add_TF(o22);

        OF mo3 = new OF(new Identifiant("MO", 3), 0, 9);
        TacheProduction o31 = new TacheProduction(mo3.ID, new Identifiant("OP", 31), 8.5);
        o31.add_activite(PERCAGE);
        mo3.add_TF(o31);

        List<OF> ofs = Arrays.asList(mo1, mo2, mo3);

        // Machines candidates
        Machine m1 = buildSimpleMachine(new Identifiant("M", 11), FRAISAGE);
        Machine m2 = buildSimpleMachine(new Identifiant("M", 21), TOURNAGE, DECOUPE);
        Machine m3 = buildSimpleMachine(new Identifiant("M", 31), PERCAGE, TOURNAGE, DECOUPE);

        List<Machine> machines = Arrays.asList(m1, m2, m3);
        List<Mainteneur> maints = new ArrayList<>();
        List<Transporter> trans = new ArrayList<>();

        SCEMPT_Algo algo = new SCEMPT_Algo(ofs, machines, maints, trans);

        // Force toutes les machines sur le même site pour l'illustration
        SCEMPT_Algo.machineSites.put(11, "S0");
        SCEMPT_Algo.machineSites.put(21, "S0");
        SCEMPT_Algo.machineSites.put(31, "S0");

        // Publication des souhaits (toutes les opérations dès le cycle 1)
        for (Client cl : algo.Clients) {
            for (TacheProduction tf : cl.ordre.S) {
                algo.E.add_TF(tf, tf.WP);
            }
        }

        // Phase machines : calcul des offres potentielles et effectives
        algo.phase2_Producteur_multiProposals();

        // Affichage des offres regroupées par opération
        System.out.println("=== Cycle 1 – offres machines (Pot / Eff) ===");
        for (Client cl : algo.Clients) {
            for (TacheProduction tf : cl.ordre.S) {
                LinkedList<Proposition> props = algo.E.get_Proposition(tf.ID);
                if (props == null || props.isEmpty()) continue;
                List<Proposition> sorted = props.stream()
                        .sorted(Comparator.comparing(p -> p.ID_resource.ordre))
                        .collect(Collectors.toList());
                System.out.println(tf.ID_ordre + " " + tf.ID_tache + "  souhait=" + tf.WP);
                for (Proposition p : sorted) {
                    System.out.println("  " + p.ID_resource + "  Pot=" + p.Pot + "  Eff=" + p.Eff);
                }
            }
        }
    }

    public static void main(String[] args) {
        if (args.length > 0 && "demo-fifo".equalsIgnoreCase(args[0])) {
            runThreeOrderFifoIllustration();
            return;
        }
        /**
         * **************************************************
         */
        /* 1) Construction des OF + Taches (exemple)         */
        /**
         * **************************************************
         */
        LinkedList<OF> listeOF = new LinkedList<>();

        // OF1
        OF of1 = new OF(new Identifiant("OF", 1), 0, 35);
        TacheProduction of1tf1 = new TacheProduction(of1.ID, new Identifiant("TF", 1), 3);
        of1tf1.add_activite(new Identifiant("F1", 1));
        TacheProduction of1tf2 = new TacheProduction(of1.ID, new Identifiant("TF", 2), 5);
        of1tf2.add_activite(new Identifiant("F2", 1));
        TacheProduction of1tf3 = new TacheProduction(of1.ID, new Identifiant("TF", 3), 8);
        of1tf3.add_activite(new Identifiant("F3", 1));
        TacheProduction of1tf4 = new TacheProduction(of1.ID, new Identifiant("TF", 4), 8);
        of1tf4.add_activite(new Identifiant("F4", 1));
        of1.add_TF(of1tf1);
        of1.add_TF(of1tf2);
        of1.add_TF(of1tf3);
        of1.add_TF(of1tf4);
        listeOF.add(of1);

        // OF2
        OF of2 = new OF(new Identifiant("OF", 2), 0, 60);
        TacheProduction o2tf1 = new TacheProduction(of2.ID, new Identifiant("TF", 1), 5);
        o2tf1.add_activite(new Identifiant("F1", 1));
        TacheProduction o2tf2 = new TacheProduction(of2.ID, new Identifiant("TF", 2), 5);
        o2tf2.add_activite(new Identifiant("F3", 1));
        TacheProduction o2tf3 = new TacheProduction(of2.ID, new Identifiant("TF", 3), 10);
        o2tf3.add_activite(new Identifiant("F1", 1));
        o2tf3.add_activite(new Identifiant("F4", 1));
        TacheProduction o2tf4 = new TacheProduction(of2.ID, new Identifiant("TF", 4), 4);
        o2tf4.add_activite(new Identifiant("F2", 1));
        TacheProduction o2tf5 = new TacheProduction(of2.ID, new Identifiant("TF", 5), 8);
        o2tf5.add_activite(new Identifiant("F2", 1));
        o2tf5.add_activite(new Identifiant("F3", 1));
        TacheProduction o2tf6 = new TacheProduction(of2.ID, new Identifiant("TF", 6), 7);
        o2tf6.add_activite(new Identifiant("F1", 1));
        o2tf6.add_activite(new Identifiant("F2", 1));
        of2.add_TF(o2tf1);
        of2.add_TF(o2tf2);
        of2.add_TF(o2tf3);
        of2.add_TF(o2tf4);
        of2.add_TF(o2tf5);
        of2.add_TF(o2tf6);
        listeOF.add(of2);

        // ... etc. (OF3, OF4, OF5, OF6)
        // (On recopie vos exemples existants)
        OF of3 = new OF(new Identifiant("OF", 3), 0, 65);
        TacheProduction of3tf1 = new TacheProduction(of3.ID, new Identifiant("TF", 1), 10);
        of3tf1.add_activite(new Identifiant("F2", 1));
        of3tf1.add_activite(new Identifiant("F3", 1));
        TacheProduction of3tf2 = new TacheProduction(of3.ID, new Identifiant("TF", 2), 8);
        of3tf2.add_activite(new Identifiant("F3", 1));
        TacheProduction of3tf3 = new TacheProduction(of3.ID, new Identifiant("TF", 3), 8);
        of3tf3.add_activite(new Identifiant("F4", 1));
        TacheProduction of3tf4 = new TacheProduction(of3.ID, new Identifiant("TF", 4), 5);
        of3tf4.add_activite(new Identifiant("F1", 1));
        TacheProduction of3tf5 = new TacheProduction(of3.ID, new Identifiant("TF", 5), 4);
        of3tf5.add_activite(new Identifiant("F2", 1));
        of3.add_TF(of3tf1);
        of3.add_TF(of3tf2);
        of3.add_TF(of3tf3);
        of3.add_TF(of3tf4);
        of3.add_TF(of3tf5);
        listeOF.add(of3);

        OF of4 = new OF(new Identifiant("OF", 4), 10, 80);
        // idem pour of4...
        TacheProduction o4tf1 = new TacheProduction(of4.ID, new Identifiant("TF", 1), 10);
        o4tf1.add_activite(new Identifiant("F1", 1));
        o4tf1.add_activite(new Identifiant("F2", 1));
        TacheProduction o4tf2 = new TacheProduction(of4.ID, new Identifiant("TF", 2), 10);
        o4tf2.add_activite(new Identifiant("F1", 1));
        o4tf2.add_activite(new Identifiant("F4", 1));
        TacheProduction o4tf3 = new TacheProduction(of4.ID, new Identifiant("TF", 3), 8);
        o4tf3.add_activite(new Identifiant("F2", 1));
        TacheProduction o4tf4 = new TacheProduction(of4.ID, new Identifiant("TF", 4), 5);
        o4tf4.add_activite(new Identifiant("F1", 1));
        TacheProduction o4tf5 = new TacheProduction(of4.ID, new Identifiant("TF", 5), 5);
        o4tf5.add_activite(new Identifiant("F2", 1));
        TacheProduction o4tf6 = new TacheProduction(of4.ID, new Identifiant("TF", 6), 4);
        o4tf6.add_activite(new Identifiant("F2", 1));
        o4tf6.add_activite(new Identifiant("F3", 1));
        of4.add_TF(o4tf1);
        of4.add_TF(o4tf2);
        of4.add_TF(o4tf3);
        of4.add_TF(o4tf4);
        of4.add_TF(o4tf5);
        of4.add_TF(o4tf6);
        listeOF.add(of4);

        OF of5 = new OF(new Identifiant("OF", 5), 15, 70);
        TacheProduction o5tf1 = new TacheProduction(of5.ID, new Identifiant("TF", 1), 7);
        o5tf1.add_activite(new Identifiant("F3", 1));
        TacheProduction o5tf2 = new TacheProduction(of5.ID, new Identifiant("TF", 2), 5);
        o5tf2.add_activite(new Identifiant("F2", 1));
        TacheProduction o5tf3 = new TacheProduction(of5.ID, new Identifiant("TF", 3), 4);
        o5tf3.add_activite(new Identifiant("F4", 1));
        TacheProduction o5tf4 = new TacheProduction(of5.ID, new Identifiant("TF", 4), 3);
        o5tf4.add_activite(new Identifiant("F1", 1));
        TacheProduction o5tf5 = new TacheProduction(of5.ID, new Identifiant("TF", 5), 5);
        o5tf5.add_activite(new Identifiant("F2", 1));
        TacheProduction o5tf6 = new TacheProduction(of5.ID, new Identifiant("TF", 6), 6);
        o5tf6.add_activite(new Identifiant("F1", 1));
        of5.add_TF(o5tf1);
        of5.add_TF(o5tf2);
        of5.add_TF(o5tf3);
        of5.add_TF(o5tf4);
        of5.add_TF(o5tf5);
        of5.add_TF(o5tf6);
        listeOF.add(of5);

        OF of6 = new OF(new Identifiant("OF", 6), 20, 85);
        TacheProduction o6tf1 = new TacheProduction(of6.ID, new Identifiant("TF", 1), 8);
        o6tf1.add_activite(new Identifiant("F1", 1));
        o6tf1.add_activite(new Identifiant("F4", 1));
        TacheProduction o6tf2 = new TacheProduction(of6.ID, new Identifiant("TF", 2), 9);
        o6tf2.add_activite(new Identifiant("F1", 1));
        o6tf2.add_activite(new Identifiant("F2", 1));
        TacheProduction o6tf3 = new TacheProduction(of6.ID, new Identifiant("TF", 3), 6);
        o6tf3.add_activite(new Identifiant("F3", 1));
        TacheProduction o6tf4 = new TacheProduction(of6.ID, new Identifiant("TF", 4), 5);
        o6tf4.add_activite(new Identifiant("F2", 1));
        TacheProduction o6tf5 = new TacheProduction(of6.ID, new Identifiant("TF", 5), 10);
        o6tf5.add_activite(new Identifiant("F2", 1));
        o6tf5.add_activite(new Identifiant("F3", 1));
        of6.add_TF(o6tf1);
        of6.add_TF(o6tf2);
        of6.add_TF(o6tf3);
        of6.add_TF(o6tf4);
        of6.add_TF(o6tf5);
        listeOF.add(of6);

        // 2) Machines
        LinkedList<Machine> listeMachines = new LinkedList<>();
        // ex. Machine M(1), M(2), M(11), etc.
        // (vous recopiez vos instanciations)
/* ========================================================= */
/*            2)  MACHINES  (référentiel 2025‑06)            */
/* ========================================================= */
/*  – Tous les composants sont en mode PHM (true)             */
/*  – Les relations AND / OR suivent votre tableau            */
/*  – Identifiants :  C0…  /  C1…  /  C2… = site S1/S2/S3     */


/* ---------- S1 : site amont ------------------------------------------ */
/* ========================================================= */
/*            2)  MACHINES  (référentiel tableau)            */
/* ========================================================= */
Machine M11 = new Machine(new Identifiant("M", 11), false);     // S1
Composant C0111 = new Composant(new Identifiant("C0111", 1), new Identifiant("m1", 1), 30, 2, true);
Composant C0112 = new Composant(new Identifiant("C0112", 1), new Identifiant("m2", 1), 25, 2, true);
M11.add_Composant(C0111);  M11.add_Composant(C0112);
Fonction F1_M11 = new Fonction(); F1_M11.add_composant(C0111.ID); F1_M11.add_composant(C0112.ID); F1_M11.logique = LogicType.AND;
M11.add_Competence(new Competence(new Identifiant("F1",1),0,1,1,F1_M11));

Machine M12 = new Machine(new Identifiant("M", 12), false);     // S1
Composant C0211 = new Composant(new Identifiant("C0211", 1), new Identifiant("m1", 1), 30, 2, true);
Composant C0212 = new Composant(new Identifiant("C0212", 1), new Identifiant("m2", 1), 25, 2, true);
Composant C0221 = new Composant(new Identifiant("C0221", 1), new Identifiant("m2", 1), 35, 2, true);
M12.add_Composant(C0211);  M12.add_Composant(C0212);  M12.add_Composant(C0221);
Fonction F1_M12 = new Fonction(); F1_M12.add_composant(C0211.ID); F1_M12.add_composant(C0212.ID); F1_M12.logique = LogicType.AND;
M12.add_Competence(new Competence(new Identifiant("F1",1),0,1,1,F1_M12));
Fonction F2_M12 = new Fonction(); F2_M12.add_composant(C0221.ID);  // mono
M12.add_Competence(new Competence(new Identifiant("F2",1),0,1,1,F2_M12));

Machine M21 = new Machine(new Identifiant("M", 21), false);     // S2
Composant C1121 = new Composant(new Identifiant("C1121", 1), new Identifiant("m1", 1), 30, 2, true);
Composant C1131 = new Composant(new Identifiant("C1131", 1), new Identifiant("m1", 1), 25, 2, true);
Composant C1132 = new Composant(new Identifiant("C1132", 1), new Identifiant("m2", 1), 20, 2, true);
M21.add_Composant(C1121); M21.add_Composant(C1131); M21.add_Composant(C1132);
Fonction F2_M21 = new Fonction(); F2_M21.add_composant(C1121.ID);
M21.add_Competence(new Competence(new Identifiant("F2",1),0,1,1,F2_M21));
Fonction F3_M21 = new Fonction(); F3_M21.add_composant(C1131.ID); F3_M21.add_composant(C1132.ID); F3_M21.logique = LogicType.OR;
M21.add_Competence(new Competence(new Identifiant("F3",1),0,1,1,F3_M21));

Machine M22 = new Machine(new Identifiant("M", 22), false);     // S2
Composant C1231 = new Composant(new Identifiant("C1231", 1), new Identifiant("m2", 1), 40, 2, true);
M22.add_Composant(C1231);
Fonction F3_M22 = new Fonction(); F3_M22.add_composant(C1231.ID);      // mono
M22.add_Competence(new Competence(new Identifiant("F3",1),0,1,1,F3_M22));

Machine M31 = new Machine(new Identifiant("M", 31), false);     // S3
Composant C2111 = new Composant(new Identifiant("C2111", 1), new Identifiant("m1", 1), 20, 2, true);
Composant C2112 = new Composant(new Identifiant("C2112", 1), new Identifiant("m1", 1), 25, 2, true);
Composant C2141 = new Composant(new Identifiant("C2141", 1), new Identifiant("m2", 1), 45, 3, true);
Composant C2142 = new Composant(new Identifiant("C2142", 1), new Identifiant("m1", 1), 50, 3, true);
M31.add_Composant(C2111); M31.add_Composant(C2112); M31.add_Composant(C2141); M31.add_Composant(C2142);
Fonction F1_M31 = new Fonction(); F1_M31.add_composant(C2111.ID); F1_M31.add_composant(C2112.ID); F1_M31.logique = LogicType.AND;
M31.add_Competence(new Competence(new Identifiant("F1",1),0,1,1,F1_M31));
Fonction F4_M31 = new Fonction(); F4_M31.add_composant(C2141.ID); F4_M31.add_composant(C2142.ID); F4_M31.logique = LogicType.AND;
M31.add_Competence(new Competence(new Identifiant("F4",1),0,1,1,F4_M31));


/* ---------- Ajout dans la liste globale ------------------------------ */
listeMachines.add(M11);  listeMachines.add(M12);
listeMachines.add(M21);  listeMachines.add(M22);
listeMachines.add(M31);

        // 3) Mainteneurs
        LinkedList<Mainteneur> listeMaint = new LinkedList<>();
        Mainteneur mt1 = new Mainteneur(new Identifiant("MT", 1));
        Fonction f_m1 = new Fonction();
        f_m1.add_composant(new Identifiant("m1", 1));
        Competence c_m1 = new Competence(new Identifiant("m1", 1), 0, 1, 3, f_m1);
        mt1.add_Competence(c_m1);

        Mainteneur mt2 = new Mainteneur(new Identifiant("MT", 2));
        Fonction f_m2 = new Fonction();
        f_m2.add_composant(new Identifiant("m2", 1));
        Competence c_m2 = new Competence(new Identifiant("m2", 1), 0, 1, 4, f_m2);
        mt2.add_Competence(c_m2);

        listeMaint.add(mt1);
        listeMaint.add(mt2);
// Exemples : personnaliser les seuils d’utilisation (heures) si désiré
C0111.seuil = 22.0;  C0112.seuil = 20.0;
C0211.seuil = 24.0;  C0212.seuil = 20.0;  C0221.seuil = 25.0;

C1121.seuil = 30.0;  C1131.seuil = 20.0;  C1132.seuil = 20.0;

C2111.seuil = 20.0;  C2112.seuil = 20.0;
C2141.seuil = 30.0;  C2142.seuil =30.0;

        // 4) Transporteurs
 
        LinkedList<Transporter> listeTrans = new LinkedList<>();
        Transporter TR1= new Transporter(new Identifiant("TR",1),"S1","S2",1.0);
        Transporter TR2= new Transporter(new Identifiant("TR",2),"S0","S2",1.0);
        listeTrans.add(TR1);
        listeTrans.add(TR2);

        /**
         * **************************************************
         */
        // On crée l'algo & on lance
        SCEMPT_Algo algo = new SCEMPT_Algo(listeOF, listeMachines, listeMaint, listeTrans);
        algo.launch();
        // 2) exporte tout
try {
    java.nio.file.Path dir = app.ExportUtils.exportAll(algo);
    System.out.println("Exports écrits dans : " + dir.toAbsolutePath());
    // Option : ouvrir automatiquement le dossier
    if (java.awt.Desktop.isDesktopSupported()) {
        java.awt.Desktop.getDesktop().open(dir.toFile());
    }
} catch (Exception ex) {
    ex.printStackTrace();
}
     // 1) Gantt TF & TM par machine
GanttBuilder.show(algo);     // machines (TF+TM)
 GanttOFBuilder.show(algo);   // OF (TF+TT)
/* 
java.nio.file.Path dir = app.ExportUtils.makeExportDir();
app.ExportUtils.saveAsPNG(w1.getChartPanel(), dir.resolve("gantt_machines.png"));
app.ExportUtils.saveAsPNG(w2.getChartPanel(), dir.resolve("gantt_of.png"));
*/
// 2) Gantt TF & TT par OF
//GanttOFBuilder.show(algo);

      // ScenarioPrinter.printAll();
    }

/* =========================================================
 *  ScenarioPrinter — impression des logs “attendus”
 *  Gabarit identique à tes exemples VS Code
 *  (cycles + plan final avec TF/TT/TM)
 *  ► Valeurs conformes au récapitulatif fourni par l’utilisateur
 * ========================================================= */
/* 

/* 

final class ScenarioPrinter {

    public static void printAll() {
        printCycles();
        printFinalPlan();
    }

    /* -----------------------------------------------------
     * Cycles – validations (format proche de tes logs)
     * (libellé OFx.TFy pour éviter l’ambiguïté TF0/TF1 globaux)
   
   
     * ----------------------------------------------------- */
    /* 

     public static void printCycles() {

        System.out.println(">>> CYCLE 1 <<<");
        System.out.println("Client valide OF1.TF1 via ([0.00,3.00],[0.00,3.00],M11)");
        System.out.println("Client valide OF2.TF1 via ([0.00,5.00],[0.00,5.00],M12)");
        System.out.println("Client valide OF3.TF1 via ([0.00,10.00],[0.00,10.00],M21)");
        System.out.println("Client valide OF4.TF1 via ([10.00,20.00],[10.00,20.00],M12)");
        System.out.println("Client valide OF5.TF1 via ([15.00,22.00],[15.00,22.00],M22)");
        System.out.println("Client valide OF6.TF1 via ([20.00,28.00],[20.00,28.00],M31)");
        System.out.println("Fin cycle 1 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 2 <<<");
        System.out.println("Client valide OF1.TF2 via ([5.00,10.00],[5.00,10.00],M12)");
        System.out.println("Client valide OF3.TF2 via ([10.00,18.00],[10.00,18.00],M21)");
        System.out.println("Client valide OF4.TF2 via ([28.00,38.00],[28.00,38.00],M31)");
        System.out.println("Client valide OF5.TF2 via ([33.00,38.00],[33.00,38.00],M12)");
        System.out.println("Client valide OF2.TF2 via ([22.00,27.00],[22.00,27.00],M22)");
        System.out.println("Client valide OF6.TF2 via ([39.00,48.00],[39.00,48.00],M12)");
        System.out.println("Fin cycle 2 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 3 <<<");
        System.out.println("Client valide OF1.TF3 via ([21.00,29.00],[21.00,29.00],M21)");
        System.out.println("Client valide OF2.TF3 via ([38.00,48.00],[38.00,48.00],M31)");
        System.out.println("Client valide OF3.TF3 via ([55.00,63.00],[55.00,63.00],M31)");
        System.out.println("Client valide OF5.TF3 via ([63.00,67.00],[63.00,67.00],M31)");
        System.out.println("Client valide OF6.TF3 via ([59.00,65.00],[59.00,65.00],M21)");
        System.out.println("Fin cycle 3 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 4 <<<");
        System.out.println("Client valide OF6.TF4 via ([65.00,70.00],[65.00,70.00],M21)");
        System.out.println("Client valide OF3.TF4 via ([69.00,74.00],[69.00,74.00],M11)");
        System.out.println("Client valide OF1.TF4 via ([67.00,75.00],[67.00,75.00],M31)");
        System.out.println("Client valide OF4.TF3 via ([43.00,51.00],[43.00,51.00],M21)");
        System.out.println("Fin cycle 4 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 5 <<<");
        System.out.println("Client valide OF2.TF4 via ([55.00,59.00],[55.00,59.00],M12)");
        System.out.println("Client valide OF4.TF4 via ([62.00,67.00],[62.00,67.00],M12)");
        System.out.println("Client valide OF5.TF4 via ([73.00,76.00],[73.00,76.00],M12)");
        System.out.println("Fin cycle 5 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 6 <<<");
        System.out.println("Client valide OF4.TF5 via ([74.00,79.00],[74.00,79.00],M12)");
        System.out.println("Client valide OF5.TF5 via ([79.00,84.00],[79.00,84.00],M12)");
        System.out.println("Client valide OF6.TF5 via ([82.00,92.00],[82.00,92.00],M21)");
        System.out.println("Fin cycle 6 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 7 <<<");
        System.out.println("Client valide OF5.TF6 via ([84.00,90.00],[84.00,90.00],M12)");
        System.out.println("Client valide OF2.TF5 via ([74.00,82.00],[74.00,82.00],M21)");
        System.out.println("Fin cycle 7 ? TF restantes=??\n");

        System.out.println(">>> CYCLE 8 <<<");
        System.out.println("Client valide OF4.TF6 via ([92.00,96.00],[92.00,96.00],M21)");
        System.out.println("Client valide OF3.TF5 via ([96.00,100.00],[96.00,100.00],M21)");
        System.out.println("Client valide OF2.TF6 via ([93.00,100.00],[93.00,100.00],M12)");
        System.out.println("Fin cycle 8 ? TF restantes=0.0\n");
    }
}
*/
    /* -----------------------------------------------------
     * Plan final – exactement au format de tes impressions
     * (TF / TM / TT)
     * ----------------------------------------------------- */
  /* 
     public static void printFinalPlan() {
        System.out.println("===== PLAN FINAL =====");
        System.out.println("ID\tWP\tProp\tFP");
        System.out.println("list TF");

        // ——— TF (résumé final par OF.TF) ———
        System.out.println("OF1, TF1        [0.00,14.00]    -       ([0.00,3.00],M11)");
        System.out.println("OF2, TF1        [0.00,26.00]    -       ([0.00,5.00],M12)");
        System.out.println("OF3, TF1        [0.00,40.00]    -       ([0.00,10.00],M21)");
        System.out.println("OF4, TF1        [10.00,48.00]   -       ([10.00,20.00],M12)");
        System.out.println("OF5, TF1        [15.00,47.00]   -       ([15.00,22.00],M22)");
        System.out.println("OF6, TF1        [20.00,55.00]   -       ([20.00,28.00],M31)");

        System.out.println("OF1, TF2        [3.00,19.00]    -       ([5.00,10.00],M12)");
        System.out.println("OF1, TF3        [8.00,27.00]    -       ([21.00,29.00],M21)");
        System.out.println("OF1, TF4        [16.00,35.00]   -       ([67.00,75.00],M31)");

        System.out.println("OF2, TF2        [5.00,31.00]    -       ([22.00,27.00],M22)");
        System.out.println("OF2, TF3        [10.00,41.00]   -       ([38.00,48.00],M31)");
        System.out.println("OF2, TF4        [20.00,45.00]   -       ([55.00,59.00],M12)");
        System.out.println("OF2, TF5        [24.00,53.00]   -       ([74.00,82.00],M21)");
        System.out.println("OF2, TF6        [32.00,60.00]   -       ([93.00,100.00],M12)");

        System.out.println("OF3, TF2        [10.00,48.00]   -       ([10.00,18.00],M21)");
        System.out.println("OF3, TF3        [18.00,56.00]   -       ([55.00,63.00],M31)");
        System.out.println("OF3, TF4        [26.00,61.00]   -       ([69.00,74.00],M11)");
        System.out.println("OF3, TF5        [31.00,65.00]   -       ([96.00,100.00],M21)");

        System.out.println("OF4, TF2        [20.00,58.00]   -       ([28.00,38.00],M31)");
        System.out.println("OF4, TF3        [30.00,66.00]   -       ([43.00,51.00],M21)");
        System.out.println("OF4, TF4        [38.00,71.00]   -       ([62.00,67.00],M12)");
        System.out.println("OF4, TF5        [43.00,76.00]   -       ([74.00,79.00],M12)");
        System.out.println("OF4, TF6        [48.00,80.00]   -       ([135.00,139.00],M21)");

        System.out.println("OF5, TF2        [22.00,52.00]   -       ([33.00,38.00],M12)");
        System.out.println("OF5, TF3        [27.00,56.00]   -       ([63.00,67.00],M31)");
        System.out.println("OF5, TF4        [31.00,59.00]   -       ([73.00,76.00],M12)");
        System.out.println("OF5, TF5        [34.00,64.00]   -       ([79.00,84.00],M12)");
        System.out.println("OF5, TF6        [39.00,70.00]   -       ([84.00,90.00],M12)");

        System.out.println("OF6, TF2        [28.00,64.00]   -       ([39.00,48.00],M12)");
        System.out.println("OF6, TF3        [37.00,70.00]   -       ([59.00,65.00],M21)");
        System.out.println("OF6, TF4        [43.00,75.00]   -       ([65.00,70.00],M21)");
        System.out.println("OF6, TF5        [48.00,85.00]   -       ([82.00,92.00],M21)");

        // ——— TM ———
        System.out.println("list TM");
        System.out.println("TM0, Mach=M12, Comp=C02111      [48.00,52.00]  -       ([48.00,52.00],MT1)");
        System.out.println("TM1, Mach=M12, Comp=C02121      [52.00,55.00]  -       ([52.00,55.00],MT2)");
        System.out.println("TM2, Mach=M12, Comp=C02121      [90.00,93.00]  -       ([90.00,93.00],MT2)");
        System.out.println("TM3, Mach=M31, Comp=C21411      [48.00,51.00]  -       ([48.00,51.00],MT2)");
        System.out.println("TM4, Mach=M31, Comp=C21421      [51.00,55.00]  -       ([51.00,55.00],MT1)");
        System.out.println("TM5, Mach=M21, Comp=C11211      [70.00,74.00]  -       ([70.00,74.00],MT1)");

        // ——— TT ———
        System.out.println("list TT");
        System.out.println("TT0,S0->S2 reason=Transport OF=OF1 TF=TF3      [10.00,16.00]   -       ([10.00,16.00],TR2)");
        System.out.println("TT1,S2->S1 reason=Transport OF=OF1 TF=TF3      [16.00,21.00]   -       ([16.00,21.00],TR1)");
        System.out.println("TT2,S0->S2 reason=Transport OF=OF1 TF=TF4      [29.00,34.00]   -       ([29.00,34.00],TR2)");

        System.out.println("TT3,S0->S2 reason=Transport OF=OF2 TF=TF2      [5.00,11.00]    -       ([5.00,11.00],TR2)");
        System.out.println("TT4,S2->S1 reason=Transport OF=OF2 TF=TF2      [11.00,16.00]   -       ([11.00,16.00],TR1)");
        System.out.println("TT5,S1->S2 reason=Transport OF=OF2 TF=TF3      [27.00,32.00]   -       ([27.00,32.00],TR1)");
        System.out.println("TT6,S2->S0 reason=Transport OF=OF2 TF=TF4      [48.00,54.00]   -       ([48.00,54.00],TR2)");
        System.out.println("TT7,S0->S2 reason=Transport OF=OF2 TF=TF5      [59.00,65.00]   -       ([59.00,65.00],TR2)");
        System.out.println("TT8,S2->S1 reason=Transport OF=OF2 TF=TF5      [65.00,70.00]   -       ([65.00,70.00],TR1)");
        System.out.println("TT9,S1->S2 reason=Transport OF=OF2 TF=TF6      [82.00,87.00]   -       ([82.00,87.00],TR1)");
        System.out.println("TT10,S2->S0 reason=Transport OF=OF2 TF=TF6     [87.00,93.00]   -       ([87.00,93.00],TR2)");

        System.out.println("TT11,S0->S2 reason=Transport OF=OF3 TF=TF4     [63.00,69.00]   -       ([63.00,69.00],TR2)");
        System.out.println("TT12,S2->S0 reason=Transport OF=OF3 TF=TF4     [43.00,49.00]   -       ([43.00,49.00],TR2)");
        System.out.println("TT13,S1->S2 reason=Transport OF=OF3 TF=TF3     [30.00,35.00]   -       ([30.00,35.00],TR1)");
        System.out.println("TT14,S0->S2 reason=Transport OF=OF3 TF=TF5     [54.00,60.00]   -       ([54.00,60.00],TR2)");
        System.out.println("TT15,S2->S1 reason=Transport OF=OF3 TF=TF5     [60.00,65.00]   -       ([60.00,65.00],TR1)");

        System.out.println("TT16,S0->S2 reason=Transport OF=OF4 TF=TF2     [20.00,26.00]   -       ([20.00,26.00],TR2)");
        System.out.println("TT17,S2->S1 reason=Transport OF=OF4 TF=TF3     [38.00,43.00]   -       ([38.00,43.00],TR1)");
        System.out.println("TT18,S1->S2 reason=Transport OF=OF4 TF=TF4     [51.00,56.00]   -       ([51.00,56.00],TR1)");
        System.out.println("TT19,S2->S0 reason=Transport OF=OF4 TF=TF4     [56.00,62.00]   -       ([56.00,62.00],TR2)");
        System.out.println("TT20,S0->S2 reason=Transport OF=OF4 TF=TF6     [124.00,130.00] -       ([124.00,130.00],TR2)");
        System.out.println("TT21,S2->S1 reason=Transport OF=OF4 TF=TF6     [130.00,135.00] -       ([130.00,135.00],TR1)");

        System.out.println("TT22,S1->S2 reason=Transport OF=OF5 TF=TF2     [22.00,27.00]   -       ([22.00,27.00],TR1)");
        System.out.println("TT23,S2->S0 reason=Transport OF=OF5 TF=TF2     [27.00,33.00]   -       ([27.00,33.00],TR2)");
        System.out.println("TT24,S0->S2 reason=Transport OF=OF5 TF=TF3     [38.00,44.00]   -       ([38.00,44.00],TR2)");
        System.out.println("TT25,S2->S0 reason=Transport OF=OF5 TF=TF4     [67.00,73.00]   -       ([67.00,73.00],TR2)");

        System.out.println("TT26,S2->S0 reason=Transport OF=OF6 TF=TF2     [33.00,39.00]   -       ([33.00,39.00],TR2)");
        System.out.println("TT27,S0->S2 reason=Transport OF=OF6 TF=TF3     [48.00,54.00]   -       ([48.00,54.00],TR2)");
        System.out.println("TT28,S2->S1 reason=Transport OF=OF6 TF=TF3     [54.00,59.00]   -       ([54.00,59.00],TR1)");
    } 
    
    

}
*/
}