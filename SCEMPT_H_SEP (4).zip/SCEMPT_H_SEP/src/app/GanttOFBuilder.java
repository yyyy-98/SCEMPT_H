package app;

import java.awt.Color;
import java.util.*;
import scemptclasses.*;

final class GanttOFBuilder {

    private GanttOFBuilder() {}

    // Palette couleur par OF (6 OF ici)
    private static final Color[] OF_PALETTE = {
        new Color(229, 57,  53),   // OF1
        new Color(251, 140, 0),    // OF2
        new Color(56,  142, 60),   // OF3
        new Color(33,  150, 243),  // OF4
        new Color(156, 39,  176),  // OF5
        new Color(255, 193, 7)     // OF6
    };

    private static final Color TT_COLOR = new Color(66, 133, 244);

    private static String shortId(Identifiant id) { return id==null? "?" : id.type + id.ordre; }

    /** Construit la fenêtre Gantt « TF & TT confirmés par OF ». */
    public static GanttWindow build(final SCEMPT_Algo algo) {
        final Environnement E = algo.E;

        LinkedHashMap<String, GanttRow> rows = new LinkedHashMap<>();
        for (Client c : algo.Clients) {
            String ofKey = c.ordre.ID.toString(); // "OF1", ...
            rows.put(ofKey, new GanttRow(ofKey));
        }

        double tMin = Double.POSITIVE_INFINITY, tMax = Double.NEGATIVE_INFINITY;

        // -------- TF (FP uniquement)
        for (Objet o : E.liste_TF) {
            if (o.FP == null) continue;
            String ofKey = o.TF.ID_ordre.toString();
            GanttRow row = rows.computeIfAbsent(ofKey, GanttRow::new);

            double s = o.FP.creneau.debut, f = o.FP.creneau.fin;
            tMin = Math.min(tMin, s);
            tMax = Math.max(tMax, f);

            int idx = Math.max(1, o.TF.ID_ordre.ordre) - 1;       // OF1→0, OF2→1...
            Color col = OF_PALETTE[idx % OF_PALETTE.length];

            String id    = ofKey + "." + o.TF.ID_tache;           // ex: OF2.TF3
            String label = "TF " + o.TF.ID_tache + " @ " + shortId(o.FP.ID_resource);

            row.add(new GanttItem(id, s, f, col, label));
        }

        // -------- TT (FP uniquement), rattachés à l’OF cible via reason="Transport OF=.. TF=.."
        for (Objet o : E.liste_TT) {
            if (o.FP == null) continue;
            String ofKey = extractOFfromReason(o.TT.reason);
            if (ofKey == null) continue;

            GanttRow row = rows.computeIfAbsent(ofKey, GanttRow::new);

            double s = o.FP.creneau.debut, f = o.FP.creneau.fin;
            tMin = Math.min(tMin, s);
            tMax = Math.max(tMax, f);

            String tfKey = extractTFfromReason(o.TT.reason);
            String id    = shortId(o.ID);                           // ex: TT7
            String label = "TT " + o.TT.origine + "→" + o.TT.destination
                         + (tfKey != null ? " (" + tfKey + ")" : "")
                         + " [" + shortId(o.FP.ID_resource) + "]";

            row.add(new GanttItem(id, s, f, TT_COLOR, label));
        }

        // Tri visuel
        for (GanttRow r : rows.values()) r.sortItemsByStart();

        // Légende
        ArrayList<GanttLegend> legend = new ArrayList<>();
        legend.add(new GanttLegend(TT_COLOR, "TT (transport)"));
        for (int i = 0; i < OF_PALETTE.length; i++)
            legend.add(new GanttLegend(OF_PALETTE[i], "TF " + "OF" + (i+1)));

        // Fenêtre
        return new GanttWindow(
                "Gantt — TF & TT confirmés par OF",
                new ArrayList<>(rows.values()),
                (Double.isFinite(tMin) ? tMin : 0.0),
                (Double.isFinite(tMax) ? tMax : 1.0),
                legend,algo
        );
    }

    /** Ouvre la fenêtre. */
    public static void show(final SCEMPT_Algo algo) {
        build(algo).setVisible(true);
    }

    // ---- helpers extraction OF/TF depuis reason "Transport OF=OF2 TF=TF3"
    private static String extractOFfromReason(String reason) {
        if (reason == null) return null;
        int k = reason.indexOf("OF=");
        if (k < 0) return null;
        int e = reason.indexOf(' ', k);
        if (e < 0) e = reason.length();
        return reason.substring(k + 3, e).trim();
    }

    private static String extractTFfromReason(String reason) {
        if (reason == null) return null;
        int k = reason.indexOf("TF=");
        if (k < 0) return null;
        int e = reason.indexOf(' ', k);
        if (e < 0) e = reason.length();
        return reason.substring(k + 3, e).trim();
    }
}
