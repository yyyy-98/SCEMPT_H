package app;
import java.util.*;
import scemptclasses.*;



final class GanttBuilder {

    /** Construit les lignes du Gantt (une ligne par machine) à partir des FP. */
    static List<GanttRow> fromEnvironment(Environnement E) {
        Map<String,GanttRow> rows = new LinkedHashMap<>();

        // ---- TF : placer sur la machine qui a été confirmée (FP.ID_resource) ----
        for (Objet o : E.liste_TF) {
            if (o.FP == null) continue;
            Identifiant mId = o.FP.ID_resource;          // Mxx
            String site = SCEMPT_Algo.detectSiteMachine(mId);
            String rowKey = mId.toString() + " (" + site + ")";
            GanttRow row = rows.computeIfAbsent(rowKey, GanttRow::new);

            String of = o.TF.ID_ordre.toString();        // "OF2"
            String tf = o.TF.ID_tache.toString();        // "TF3"
            String label = of + "." + tf;

            row.add(new GanttItem(label,
                    o.FP.creneau.debut,
                    o.FP.creneau.fin,
                    colorForOF(o.TF.ID_ordre.ordre),
                    "TF"));
        }

        // ---- TM : les afficher sur la LIGNE de la machine entretenue ----
        for (Objet o : E.liste_TM) {
            if (o.FP == null) continue;
            Identifiant mId = o.TM.ID_Machine;           // machine entretenue
            String site = SCEMPT_Algo.detectSiteMachine(mId);
            String rowKey = mId.toString() + " (" + site + ")";
            GanttRow row = rows.computeIfAbsent(rowKey, GanttRow::new);

            String label = "TM " + o.TM.ID_Composant.toString();
            row.add(new GanttItem(label,
                    o.FP.creneau.debut,
                    o.FP.creneau.fin,
                    new java.awt.Color(90, 90, 255),     // bleu TM
                    "TM"));
        }

        // Ordonner lignes et barres
        List<GanttRow> list = new ArrayList<>(rows.values());
        list.sort(Comparator.comparing(r -> r.name));
        for (GanttRow r : list) {
            r.items.sort(Comparator.comparingDouble(it -> it.start));
        }
        return list;
    }

    private static java.awt.Color colorForOF(int ofN) {
        switch (ofN % 6) {
            case 1: return new java.awt.Color(237, 28, 36);   // rouge
            case 2: return new java.awt.Color(0, 114, 188);   // bleu
            case 3: return new java.awt.Color(34, 177, 76);   // vert
            case 4: return new java.awt.Color(255, 127, 39);  // orange
            case 5: return new java.awt.Color(163, 73, 164);  // violet
            default: return new java.awt.Color(255, 201, 14); // jaune
        }
    }
    // ---------------------------------------------------------------------
// Affichage direct : construit et ouvre la fenêtre Gantt (TF & TM / machine)
// ---------------------------------------------------------------------
public static void show(final SCEMPT_Algo algo) {
    // 1) lignes (une par machine) à partir des FP
    java.util.List<GanttRow> rows = fromEnvironment(algo.E);

    // 2) bornes temporelles globales
    double tMin = Double.POSITIVE_INFINITY, tMax = Double.NEGATIVE_INFINITY;

    for (GanttRow r : rows) {
        for (GanttItem it : r.items) {
            tMin = Math.min(tMin, it.start);
            // si votre GanttItem n'a pas de getter 'end()', remplacez par (it.start + it.duration)
            double end = it.start + it.duration(); // au cas où
            tMax = Math.max(tMax, end);
        }
    }
    if (!Double.isFinite(tMin)) { tMin = 0.0; tMax = 1.0; }

    // 3) légende
    java.util.ArrayList<GanttLegend> legend = new java.util.ArrayList<>();
    legend.add(new GanttLegend(colorForOF(1), "TF (couleur par OF)"));
    legend.add(new GanttLegend(new java.awt.Color(90, 90, 255), "TM (bleu)"));

    // 4) ouverture de la fenêtre
    new GanttWindow(
            "Gantt — TF & TM confirmés par machine",
            rows, tMin, tMax, legend,algo
    ).setVisible(true);
    
}
    

}
