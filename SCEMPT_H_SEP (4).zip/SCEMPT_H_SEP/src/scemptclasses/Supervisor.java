package scemptclasses;

public class Supervisor {

    private static Supervisor instance;
    private boolean accessOpen = false;

    public enum Phase {
        CLIENTS_PUBLISH,
        PRODUCERS_PROPOSE,
        VIRTUALS_ROUTE,
        RESOURCES_PROPOSE,
        CLIENTS_VALIDATE,
        APPLY_VALIDATIONS
    }

    private Phase currentPhase = Phase.CLIENTS_PUBLISH;
    private int cycle = 0;

    private Supervisor() {}

    public static Supervisor get() {
        if (instance == null) instance = new Supervisor();
        return instance;
    }

    public void openAccess()  { accessOpen = true;  }
    public void closeAccess() { accessOpen = false; }
    public boolean isOpen()   { return accessOpen;  }

    public void nextCycle() {
        cycle++;
        System.out.println("[Supervisor] === NEW CYCLE #" + cycle + " ===");
    }

    public void nextPhase(Phase p) {
        currentPhase = p;
        System.out.println("[Supervisor] Phase=" + p + " (cycle=" + cycle + ")");
    }

    public Phase getCurrentPhase() { return currentPhase; }
    public int getCycle()          { return cycle; }
}
