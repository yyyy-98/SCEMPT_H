package scemptclasses;

import java.util.*;
/**
 * **************************************************
 */
/*            Transporter                            */
/**
 * **************************************************
 */
public class Transporter {

    public Identifiant ID;
    public String routeOrigine, routeDestination;
    public double aptitude;
    public LinkedList<Position> planning = new LinkedList<>();

    public Transporter(Identifiant id, String o, String d, double apt) {
        this.ID = id;
        this.routeOrigine = o;
        this.routeDestination = d;
        this.aptitude = apt;
    }

    public void add_to_planning(Position p) {
        planning.add(p);
        trier_planning();
    }

    public void trier_planning() {
        Position[] arr = planning.toArray(new Position[0]);
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].creneau.debut < arr[min].creneau.debut) {
                    min = j;
                }
            }
            if (min != i) {
                Position tmp = arr[min];
                arr[min] = arr[i];
                arr[i] = tmp;
            }
        }
        planning.clear();
        planning.addAll(Arrays.asList(arr));
    }

    public boolean chevaucher(Interval i1, Interval i2) {
        if (i1.debut >= i2.fin) {
            return false;
        }
        if (i1.fin <= i2.debut) {
            return false;
        }
        return true;
    }

    public Interval get_position_disponible(Interval I) {

    /* trou au plus tôt dans la fenêtre infinie [I.debut ; +∞) */
    double start = I.debut, dur = I.getTaille();
    for (Position p : planning) {
        if (p.creneau.fin <= start) continue;
        if (p.creneau.debut - start >= dur) break;    // trou trouvé
        start = p.creneau.fin;                        // sinon on saute après
    }
    return new Interval(start, start + dur);
}

    public boolean peutTransporter(TacheTransport TT) {
        return (TT.origine.equals(routeOrigine) && TT.destination.equals(routeDestination))
                || (TT.origine.equals(routeDestination) && TT.destination.equals(routeOrigine));
    }

    public void add_TT(TacheTransport TT, Interval i) {
        Position p = new Position(TT.ID, this.ID, i);
        add_to_planning(p);
    }

    @Override
    public String toString() {
        return "Transporter " + ID;
    }
}
