package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            Fonction                               */
/**
 * **************************************************
 */
/* ===================================================== */
/*                   Fonction.java                        */
/* ===================================================== */
/* ===================================================== */
/*                   Fonction.java                        */
/* ===================================================== */
public class Fonction {

    public LinkedList<Identifiant> liste_composant = new LinkedList<>();
    public LogicType logique = LogicType.AND;   // AND par défaut

    public Fonction() {}

    public Fonction(Fonction F) {
        this.liste_composant.addAll(F.liste_composant);
        this.logique = F.logique;
    }
    public void add_composant(Identifiant c) { liste_composant.add(c); }
}
