package scemptclasses;

import java.util.*;

/**
 * **************************************************
 *                 SCEMPT_Algo
 *  Orchestrateur SCEMPT aligné SCEM/SCET (article)
 * **************************************************
 */
public class SCEMPT_Algo {

    /* ---------- registres d’agents ---------------------------------- */
    public final LinkedList<Client>      Clients       = new LinkedList<>();
    public final LinkedList<Producteur>  Producteurs   = new LinkedList<>();
    public final LinkedList<Mainteneur>  Mainteneurs   = new LinkedList<>();
    public final LinkedList<Transporter> Transporteurs = new LinkedList<>();
    public final TransporteurVirtuel     VirtualTrans  = new TransporteurVirtuel(); // utilisé seulement pour publier des offres TT si besoin
    public VirtualMaintainer             VirtualMaint;                                // passerelle SCEM

    /* ---------- constantes PHM / risques ----------------------------- */
    public static final double PREVENTIVE_RATIO       = 0.80; // préventif (après TF) si ≥80% de λ — gardé mais jamais “forcé” avant sélection
    public static final boolean PUBLISH_TM_DURING_OFFERS = false;

    public static final double PHM_SEUIL_FACTOR       = 0.80;
    public static final double PHM_BEFORE_MARGIN      = 0.0;
    public static final double PHM_AFTER_MARGIN       = 2.0;
    public static final double PHM_AFTER_LOOKAHEAD    = 24.0;

    public static final double RISK_SEUIL_KO_TF       = 0.08; // seuil court (slot TF)
    public static final double RISK_SEUIL_KO_FUNCTION = 0.4; // seuil horizon H
    public static final double RISK_LOOKAHEAD_HOURS   = 72.0;

    public static final boolean DEBUG_RISK            = false;
    private void dbg(String s){ if (DEBUG_RISK) System.out.println(s); }

    /* ---------- outils partagés ------------------------------------- */
    public final Pathfinder    pathfinder = new Pathfinder();
    public final Environnement E          = new Environnement();
    public final Auctioneer    auctioneer;

    /* ---------- statiques accessibles partout ----------------------- */
    public static SCEMPT_Algo instance;                      // singleton
    public static final Map<Integer,String> machineSites = new HashMap<>();

    /* ---------- paramétrage ---------------------------------------- */
    private final int maxCycles = 200;
    private int  nCycle   = 0;
    private int  otCount  = 0;
    private boolean needReplan = false;

    /* ---------- drapeaux cycle ------------------------------------- */
    public boolean anyValidatedInThisCycle = false;

    /* ================================================================= */
    /*  TYPES internes                                                   */
    /* ================================================================= */
    public static class TFSelection {
        public final Client client; public final TacheProduction tf; public final Proposition offer;
        public TFSelection(Client c, TacheProduction tf, Proposition p){ this.client=c; this.tf=tf; this.offer=p; }
    }
    public static final class FunctionRisk {
        public final double pKO, pLR;
        public FunctionRisk(double pKO, double pLR) { this.pKO=pKO; this.pLR=pLR; }
    }

    /* ================================================================= */
    /*  CONSTRUCTEUR                                                     */
    /* ================================================================= */
    public SCEMPT_Algo(List<OF> ofs, List<Machine> machs, List<Mainteneur> mts, List<Transporter> trs) {
        instance = this;
        ofs.forEach(of -> Clients.add(new Client(of)));
        machs.forEach(m -> Producteurs.add(new Producteur(m)));
        Mainteneurs.addAll(mts);
        Transporteurs.addAll(trs);
        VirtualTrans.addTransporters(Transporteurs);
        VirtualMaint = new VirtualMaintainer(Mainteneurs);

        auctioneer = new Auctioneer(E, Producteurs);

        machineSites.put(11,"S0"); machineSites.put(12,"S0");
        machineSites.put(21,"S1"); machineSites.put(22,"S1");
        machineSites.put(31,"S2");
    }

    /* ================================================================= */
    /*  U T I L I T A I R E S                                            */
    /* ================================================================= */
    public static String detectSiteMachine(Identifiant machineID) {
        return machineSites.getOrDefault(machineID.ordre,"??");
    }
    private Machine machineById(Identifiant mid) {
        for (Producteur p : Producteurs) if (p.machine.ID.equals(mid)) return p.machine;
        return null;
    }

    /** Fin réelle de la TF précédente (sinon date R de l’OF). */
    public double dateFinPrecedente(TacheProduction tf) {
        Client c = Clients.stream().filter(cl -> cl.ordre.ID.equals(tf.ID_ordre)).findFirst().orElse(null);
        if (c==null) return tf.R;
        List<TacheProduction> seq = c.ordre.S;
        int idx = seq.indexOf(tf);
        if (idx<=0) return c.ordre.R;
        Position fp = E.get_Final(seq.get(idx-1).ID);
        return fp!=null ? fp.creneau.fin : seq.get(idx-1).R;
    }

    /** Site de la TF précédente (vide si aucune ou pas fixée). */
    public static String siteOfPreviousTF(TacheProduction tf) {
        Client c = instance.Clients.stream().filter(cl -> cl.ordre.ID.equals(tf.ID_ordre)).findFirst().orElse(null);
        if (c==null) return "";
        List<TacheProduction> seq = c.ordre.S;
        int idx = seq.indexOf(tf);
        if (idx<=0) return "";
        Position fp = instance.E.get_Final(seq.get(idx-1).ID);
        return fp==null? "" : detectSiteMachine(fp.ID_resource);
    }

    /** Somme des durées de transport inter‑sites. */
    public double travelTime(String from, String to) {
        if (from.isEmpty() || from.equals(to)) return 0.0;
        return pathfinder.genererTachesTransport(from,to,0,"calc").stream().mapToDouble(tt -> tt.duree).sum();
    }

    /** Date de démarrage la plus tôt d’une TF sur une machine donnée. */
    public double earliestReadyTimeFor(TacheProduction tf, Identifiant machineID) {
        double finPrev  = dateFinPrecedente(tf);
        String sitePrev = siteOfPreviousTF(tf);
        String siteMac  = detectSiteMachine(machineID);
        double tTrav    = travelTime(sitePrev, siteMac);   // 0 si même site

        // Si des TT (déjà fixés) existent pour cette TF, on impose leur fin
        double ttEnd = 0.0;
        String reason = "Transport OF="+tf.ID_ordre+" TF="+tf.ID_tache;
        for (Objet o : E.liste_TT) {
            if (o.TT.reason != null && o.TT.reason.equals(reason) && o.FP != null) {
                ttEnd = Math.max(ttEnd, o.FP.creneau.fin);
            }
        }
        return Math.max(Math.max(tf.R, finPrev + tTrav), ttEnd);
    }

    /* ================================================================= */
    /*  HORIZON & RISQUES FONCTION                                       */
    /* ================================================================= */
    public Interval computeHorizonForFunction(Identifiant machineID, Fonction f, double start) {
        Machine mach = machineById(machineID);
        if (mach == null) return new Interval(start, start + 1.0);
        if (f == null)     return new Interval(start, start + RISK_LOOKAHEAD_HOURS);

        double end = start;
        for (Objet o : E.liste_TF) {
            if (o.TF == null) continue;

            boolean usesF = false;
            for (Identifiant act : o.TF.list_Activite) {
                Competence c = mach.get_Competence(act);
                if (c != null && c.fonction == f) { usesF = true; break; }
            }
            if (!usesF) continue;

            if (E.is_Fixed(o.ID)) {
                Position fp = E.get_Final(o.ID);
                if (fp != null && machineID.equals(fp.ID_resource) && fp.creneau.fin > end) end = fp.creneau.fin;
            } else if (o.TF.WP != null) {
                end = Math.max(end, o.TF.WP.fin);
            }
        }
        if (end < start) end = start + 1.0;
        if (end > start + RISK_LOOKAHEAD_HOURS) end = start + RISK_LOOKAHEAD_HOURS;
        return new Interval(start, end);
    }
    private Interval computeHorizonForActivities(Identifiant machineID, List<Identifiant> activities, double start) {
        Machine mach = machineById(machineID);
        if (mach == null || activities == null || activities.isEmpty()) return new Interval(start, start + 1.0);

        double end = start;
        for (Objet o : E.liste_TF) {
            if (o.TF == null) continue;
            boolean intersects = false;
            for (Identifiant a : o.TF.list_Activite) for (Identifiant b : activities) { if (a.equals(b)) { intersects = true; break; } }
            if (!intersects) continue;

            if (E.is_Fixed(o.ID)) {
                Position fp = E.get_Final(o.ID);
                if (fp != null && machineID.equals(fp.ID_resource) && fp.creneau.fin > end) end = fp.creneau.fin;
            } else if (o.TF.WP != null) {
                end = Math.max(end, o.TF.WP.fin);
            }
        }
        if (end < start) end = start + 1.0;
        if (end > start + RISK_LOOKAHEAD_HOURS) end = start + RISK_LOOKAHEAD_HOURS;
        return new Interval(start, end);
    }

    private FunctionRisk computeRiskFromComponentsAND(Machine mach, List<Composant> comps, Interval H) {
        if (mach == null || comps == null || comps.isEmpty()) return new FunctionRisk(0.0,0.0);
        double prod = 1.0;
        for (Composant c : comps) {
            double pi = (c != null) ? c.proba_fail_over_horizon(H) : 1.0;
            if (pi < 0) pi = 0; if (pi > 1) pi = 1;
            prod *= (1.0 - pi);
        }
        return new FunctionRisk(1.0 - prod, 0.0);
    }

    public FunctionRisk computeFunctionRiskOnHorizon(Machine mach, Fonction f, Interval H) {
        if (mach == null || f == null) return new FunctionRisk(0.0,0.0);
        ArrayList<Double> p = new ArrayList<>();
        for (Identifiant cid : f.liste_composant) {
            Composant c = mach.get_Composant(cid);
            double pi = (c != null) ? c.proba_fail_over_horizon(H) : 1.0;
            if (pi < 0) pi = 0; if (pi > 1) pi = 1;
            p.add(pi);
        }
        if (p.isEmpty()) return new FunctionRisk(0.0,0.0);

        double pKO, pLR = 0.0;
        if (f.logique == LogicType.AND) {
            double prod = 1.0; for (double pi : p) prod *= (1.0 - pi);
            pKO = 1.0 - prod;
        } else {
            double prodAll = 1.0; for (double pi : p) prodAll *= pi;  // toutes KO
            pKO = prodAll;
            if (p.size() >= 2) {
                double sum = 0.0;
                for (int i=0;i<p.size();i++) {
                    double survive_i = 1.0 - p.get(i);
                    double prodOthers = 1.0;
                    for (int j=0;j<p.size();j++) if (j!=i) prodOthers *= p.get(j);
                    sum += survive_i * prodOthers;
                }
                pLR = sum;
            }
        }
        return new FunctionRisk(Math.max(0, Math.min(1, pKO)), Math.max(0, Math.min(1, pLR)));
    }

    public Identifiant chooseComponentToMaintain(Machine mach, Fonction f, Interval H) {
        if (f == null || f.liste_composant == null || f.liste_composant.isEmpty()) return null;
        FunctionRisk base = computeFunctionRiskOnHorizon(mach, f, H);
        double pKO0 = base.pKO;

        Identifiant best = null; double bestDelta = 0.0;
        for (Identifiant cid : f.liste_composant) {
            Composant c = mach.get_Composant(cid);
            double pk_new = (c != null) ? c.proba_fail_over_horizon_as_new(H) : 0.0;

            double pKO_new;
            if (f.logique == LogicType.AND) {
                double prod = 1.0;
                for (Identifiant id2 : f.liste_composant) {
                    double pi = id2.equals(cid) ? pk_new : mach.get_Composant(id2).proba_fail_over_horizon(H);
                    pi = Math.max(0, Math.min(1, pi));
                    prod *= (1.0 - pi);
                }
                pKO_new = 1.0 - prod;
            } else {
                double prodAll = 1.0;
                for (Identifiant id2 : f.liste_composant) {
                    double pi = id2.equals(cid) ? pk_new : mach.get_Composant(id2).proba_fail_over_horizon(H);
                    pi = Math.max(0, Math.min(1, pi));
                    prodAll *= pi;
                }
                pKO_new = prodAll;
            }
            double delta = pKO0 - pKO_new;
            if (delta > bestDelta + 1e-12) { bestDelta = delta; best = cid; }
        }
        return best;
    }

    /* ================================================================= */
    /*  Détection & demande TM pour une TF retenue (avant validation)     */
    /* ================================================================= */
    private List<TacheMaintenance> assessAndCreateTMRequestsForTF(Producteur prod, TacheProduction tf, Interval tfBase) {
        ArrayList<TacheMaintenance> created = new ArrayList<>();
        if (prod == null || tf == null || tfBase == null) return created;

        Machine mach = prod.machine;
        double durTF = tfBase.getTaille();
        Interval H_tf = new Interval(tfBase.debut, tfBase.fin);  // horizon court = juste la TF
        List<Fonction> fonctions = mach.fonctionsPourTF(tf);

        if (fonctions != null && !fonctions.isEmpty()) {
            for (Fonction f : fonctions) {
                FunctionRisk r_tf = computeFunctionRiskOnHorizon(mach, f, H_tf);

                boolean cross = false; Identifiant compCross = null;
                for (Identifiant cid : f.liste_composant) {
                    Composant c = mach.get_Composant(cid);
                    if (c != null && (c.willCrossThreshold(durTF) || c.temps_marche + durTF >= c.seuil - 1e-9)) {
                        cross = true; compCross = cid; break;
                    }
                }

                boolean needTM = (r_tf.pKO > RISK_SEUIL_KO_TF) || cross;
                if (!needTM) {
                    Interval H_long = computeHorizonForFunction(mach.ID, f, tfBase.debut);
                    FunctionRisk r_f = computeFunctionRiskOnHorizon(mach, f, H_long);
                    needTM = (r_f.pKO > RISK_SEUIL_KO_FUNCTION);
                }
                if (!needTM) continue;

                Identifiant compId = (compCross != null) ? compCross
                        : chooseComponentToMaintain(mach, f, (r_tf.pKO > RISK_SEUIL_KO_TF) ? H_tf : computeHorizonForFunction(mach.ID,f,tfBase.debut));
                if (compId == null) continue;

                Composant comp = mach.get_Composant(compId);
                double dTM = (comp != null ? comp.temps_reparation : 2.0);
                double rel = Math.max(0.0, tfBase.debut - dTM); // placer AVANT la TF

                TacheMaintenance tm = new TacheMaintenance(mach.ID, compId, dTM, rel);
                if (comp != null) tm.add_activite(comp.type);
                E.add_TM(tm);
                created.add(tm);
            }
            return created;
        }

        // Fallback : pas de "fonction" -> AND sur composants utilisés
        List<Composant> used = mach.get_Composant_inCompetences(tf.list_Activite);
        if (used == null || used.isEmpty()) return created;

        FunctionRisk r_and = computeRiskFromComponentsAND(mach, used, H_tf);
        boolean cross = false; Identifiant compCross = null;
        for (Composant c : used) {
            if (c != null && (c.willCrossThreshold(durTF) || c.temps_marche + durTF >= c.seuil - 1e-9)) {
                cross = true; compCross = c.ID; break;
            }
        }
        boolean needTM = (r_and.pKO > RISK_SEUIL_KO_TF) || cross;

        if (!needTM) {
            Interval H_long = computeHorizonForActivities(mach.ID, tf.list_Activite, tfBase.debut);
            FunctionRisk r_long = computeRiskFromComponentsAND(mach, used, H_long);
            needTM = (r_long.pKO > RISK_SEUIL_KO_FUNCTION);
        }
        if (!needTM) return created;

        // choix composant (Desforges – meilleur gain)
        Identifiant compId = null; double bestDelta = 0;
        FunctionRisk base = computeRiskFromComponentsAND(mach, used, (r_and.pKO > RISK_SEUIL_KO_TF) ? H_tf : computeHorizonForActivities(mach.ID, tf.list_Activite, tfBase.debut));
        for (Composant c : used) {
            double pk_new = (c != null) ? c.proba_fail_over_horizon_as_new(H_tf) : 0.0;
            double prodSurvive = 1.0;
            for (Composant cc : used) {
                double pi = (cc == c) ? pk_new : cc.proba_fail_over_horizon(H_tf);
                pi = Math.max(0,Math.min(1,pi));
                prodSurvive *= (1.0 - pi);
            }
            double pKO_new = 1.0 - prodSurvive;
            double delta = base.pKO - pKO_new;
            if (delta > bestDelta + 1e-12) { bestDelta = delta; compId = c.ID; }
        }
        if (compId == null) return created;

        Composant comp = mach.get_Composant(compId);
        double dTM = (comp != null ? comp.temps_reparation : 2.0);
        double rel = Math.max(0.0, tfBase.debut - dTM);

        TacheMaintenance tm = new TacheMaintenance(mach.ID, compId, dTM, rel);
        if (comp != null) tm.add_activite(comp.type);
        E.add_TM(tm);
        created.add(tm);

        return created;
    }

    /* ================================================================= */
    /*  FILET – pas de chevauchement TF/TM sur la même machine           */
    /* ================================================================= */
    public Interval findNextFreeSlot(Identifiant mID, Interval base, Identifiant excludeTF) {
        double start = base.debut;
        double dur   = base.getTaille();

        boolean restart;
        do {
            restart = false;

            // TF déjà fixées sur cette machine
            for (Objet o : E.liste_TF) {
                if (o.ID.equals(excludeTF) || o.FP == null) continue;
                if (!o.FP.ID_resource.equals(mID)) continue;
                Interval c = o.FP.creneau;
                if (c.debut < start + dur && start < c.fin) { start = c.fin; restart = true; break; }
            }
            if (restart) continue;

            // TM fixées sur CETTE machine (ressource FP=mainteneur ; on vérifie via TM.ID_Machine)
            for (Objet o : E.liste_TM) {
                if (o.FP == null || o.TM == null) continue;
                if (!mID.equals(o.TM.ID_Machine)) continue;
                Interval c = o.FP.creneau;
                if (c.debut < start + dur && start < c.fin) { start = c.fin; restart = true; break; }
            }

        } while (restart);

        return new Interval(start, start + dur);
    }

    /* ================================================================= */
    /*  PHASE 2 – Producteurs : offres multi‑machines (FIFO)             */
    /* ================================================================= */
    public void phase2_Producteur_multiProposals() {
        Producteurs.forEach(Producteur::activation);

        // TF non fixées publiées
        List<TacheProduction> allCandidates = new ArrayList<>();
        for (Objet obj : E.liste_TF) if (!E.is_Fixed(obj.ID)) allCandidates.add(obj.TF);

        for (Producteur pr : Producteurs) {
            List<TacheProduction> candidatesForP = new ArrayList<>();
            for (TacheProduction tf0 : allCandidates) {
                if (pr.machine.get_capability(tf0.list_Activite) > 0) candidatesForP.add(tf0);
            }
            if (candidatesForP.isEmpty()) continue;

            final Identifiant mid = pr.machine.ID;
            candidatesForP.sort(Comparator.comparingDouble(tf0 -> earliestReadyTimeFor(tf0, mid)));

            for (TacheProduction tf0 : candidatesForP) {
                double cap = Math.max(1e-9, pr.machine.get_capability(tf0.list_Activite));
                double deb0 = earliestReadyTimeFor(tf0, mid);
                double dur  = tf0.duree / cap;

                TacheProduction tf = new TacheProduction(tf0);
                tf.duree = dur; tf.R = deb0; tf.WP = new Interval(Math.max(tf0.WP.debut, deb0), tf0.WP.fin);

                pr.list_TF.add(tf);
                pr.list_TF_principale.add(tf);

                Proposition p = new Proposition(tf.ID, mid);
                pr.list_prop.add(p);
            }
        }

        for (Producteur pr : Producteurs) {
            if (pr.list_TF.isEmpty()) continue;
            pr.Position_Potentielle();  // PP
            pr.Position_Effective();    // EP (simulation locale des TM avant)
            pr.set_Proposition(E);      // publication (aucune réservation)
        }
    }

    /* ================================================================= */
    /*  FILE d’attente : TF retenues par les clients                     */
    /* ================================================================= */
    private final LinkedList<TFSelection> pendingSelections = new LinkedList<>();
    public void queueSelectedTF(Client c, TacheProduction tf, Proposition p) { pendingSelections.add(new TFSelection(c,tf,p)); }

    /* ================================================================= */
    /*  APPLICATION des sélections client (article fig. 3)               */
    /*   1) valider TT (SCET) → set_Final                                */
    /*   2) demander & valider TM(AVANT) nécessaires (SCEM)              */
    /*   3) valider TF (après TT & TM)                                   */
    /*   4) publier TF suivante                                          */
    /* ================================================================= */
    public void applySelectedValidations() {
        if (pendingSelections.isEmpty()) return;

        // phase maintenance : les mainteneurs publient PP/EP (Pot=Eff)
        Runnable runMaintPhase = () -> {
            if (VirtualMaint != null) VirtualMaint.publishMaintenanceOffers(E);
            else for (Mainteneur m : Mainteneurs) { m.activation(); m.get_TM(E); m.trier(); m.Position_Potentielle(); m.Position_Effective(); m.set_Proposition(E); }
        };

        while (!pendingSelections.isEmpty()) {
            TFSelection sel = pendingSelections.pollFirst();
            Client client = sel.client; TacheProduction tf = sel.tf; Proposition offer = sel.offer;

            Producteur prod = null;
            for (Producteur p : Producteurs) if (p.machine.ID.equals(offer.ID_resource)) { prod = p; break; }
            if (prod == null) continue;

            // (1) TRANSPORTS nécessaires (chaîne)
            int idx = client.ordre.S.indexOf(tf);
            double finPrev = client.ordre.R; String sitePrev = "";
            if (idx > 0) {
                TacheProduction prev = client.ordre.S.get(idx-1);
                Position fpPrev = E.get_Final(prev.ID);
                if (fpPrev != null) { finPrev = fpPrev.creneau.fin; sitePrev = detectSiteMachine(fpPrev.ID_resource); }
            }
            String siteChosen = detectSiteMachine(offer.ID_resource);
            double cursor = finPrev;

            if (!sitePrev.isEmpty() && !sitePrev.equals(siteChosen)) {
                String reason = "Transport OF=" + tf.ID_ordre + " TF=" + tf.ID_tache;
                LinkedList<TacheTransport> segs = pathfinder.genererTachesTransport(sitePrev, siteChosen, cursor, reason);

                for (TacheTransport tt : segs) {
                    Transporter bestTr = null; Interval bestI = null;
                    for (Transporter tr : Transporteurs) {
                        if (!tr.peutTransporter(tt)) continue;
                        Interval cand = tr.get_position_disponible(new Interval(cursor, cursor + tt.duree));
                        if (bestI == null || cand.fin < bestI.fin) { bestI = cand; bestTr = tr; }
                    }
                    if (bestTr == null) continue;

                    tt.ID_transport = bestTr.ID;
                    E.add_TT(tt);
                    E.set_Final(tt.ID, new Position(tt.ID, bestTr.ID, bestI));
                    bestTr.add_TT(tt, bestI);
                    cursor = bestI.fin;
                }
            }

            // (2) base TF requise (≥ fin TT)
            double dur = (offer.Eff != null ? offer.Eff.getTaille() : (offer.Pot != null ? offer.Pot.getTaille() : tf.duree));
            double startReq = (offer.Eff != null ? offer.Eff.debut : (offer.Pot != null ? offer.Pot.debut : tf.R));
            Interval tfBase = new Interval(Math.max(cursor, startReq), Math.max(cursor, startReq) + dur);

            // (3) demandes TM AVANT si nécessaire
            List<TacheMaintenance> createdTMs = assessAndCreateTMRequestsForTF(prod, tf, tfBase);

            // (4) recueillir PP/EP TM puis valider celles‑ci (avant TF)
            double beforeEnd = tfBase.debut;
            if (!createdTMs.isEmpty()) {
                runMaintPhase.run();
                for (TacheMaintenance tm : createdTMs) {
                    LinkedList<Proposition> props = E.get_Proposition(tm.ID);
                    if (props == null || props.isEmpty()) continue;

                    Proposition best = props.stream().filter(p -> p.Eff != null)
                            .min(Comparator.comparingDouble(p -> p.Eff.fin)).orElse(null);
                    if (best == null) continue;

                    // valider TM
                    E.set_Final(tm.ID, new Position(tm.ID, best.ID_resource, best.Eff));
                    beforeEnd = Math.max(beforeEnd, best.Eff.fin);

                    // MAJ plannings + reset RUL
                    Mainteneur m = null;
                    for (Mainteneur mm : Mainteneurs) if (mm.ID.equals(best.ID_resource)) { m = mm; break; }
                    if (m != null) m.add_to_planning_principale(new Position(tm.ID, best.ID_resource, best.Eff));
                    prod.machine.add_TM(tm.ID, tm.ID_Composant, best.Eff);
                    prod.Machine_principale.add_TM(tm.ID, tm.ID_Composant, best.Eff);

                    Composant comp  = prod.machine.get_Composant(tm.ID_Composant);
                    if (comp  != null) { comp.temps_marche = 0; comp.refreshNextDueDate(); }
                    Composant compP = prod.Machine_principale.get_Composant(tm.ID_Composant);
                    if (compP != null) { compP.temps_marche = 0; compP.refreshNextDueDate(); }
                }
            }

            // (5) valider TF (après TT + TM avant)
            Interval tfCand = new Interval(Math.max(beforeEnd, tfBase.debut), Math.max(beforeEnd, tfBase.debut) + dur);
            Interval tfSlot = findNextFreeSlot(offer.ID_resource, tfCand, tf.ID);

            E.set_Final(tf.ID, new Position(tf.ID, offer.ID_resource, tfSlot));
            prod.machine.add_TF(tf, tfSlot);
            prod.Machine_principale.add_TF(tf, tfSlot);
            anyValidatedInThisCycle = true;

            // (6) rafraîchir fenêtres & publier TF suivante
            client.ordre.refreshWindowsFrom(idx + 1, tfSlot.fin);
            if (idx + 1 < client.ordre.S.size()) {
                TacheProduction next = client.ordre.S.get(idx + 1);
                if (next.ID == null) E.add_TF(next, next.WP);
                Proposition ps = new Proposition(next.ID, new Identifiant("PS",-1));
                ps.Pot = next.WP; ps.Eff = null; E.add_Proposition(ps);
            }
        }

        // synchronisations usuelles
        Mainteneurs.forEach(m -> { m.lire_acceptation(E); m.remove_orphan_TM(E); });
        Producteurs.forEach(p -> { p.lire_validation(E); p.validation_maintenance_load(E); });
    }

    /* ================================================================= */
    /*  Forçage : si rien retenu, on “sélectionne” une TF (pas de fix)    */
    /* ================================================================= */
    private Client clientOf(TacheProduction tf) {
        for (Client c : Clients) if (c.ordre.ID.equals(tf.ID_ordre)) return c;
        return null;
    }
    public void forceOneByPotentialIfNeeded() {
        if (anyValidatedInThisCycle) return;

        Proposition chosen = null; TacheProduction chosenTF = null; double bestDist = Double.POSITIVE_INFINITY;
        for (Objet o : E.liste_TF) {
            if (E.is_Fixed(o.ID)) continue;
            LinkedList<Proposition> props = E.get_Proposition(o.ID);
            if (props == null) continue;
            double wpStart = o.TF.WP.debut;
            for (Proposition p : props) {
                if (p.Pot == null || !"M".equals(p.ID_resource.type)) continue;
                double d = Math.abs(p.Pot.debut - wpStart);
                if (d < bestDist) { bestDist = d; chosen = p; chosenTF = o.TF; }
            }
        }
        if (chosen != null && chosenTF != null) {
            Client cl = clientOf(chosenTF);
            if (cl == null) return;

            if (chosen.Eff == null) {
                double dur = (chosen.Pot != null ? chosen.Pot.getTaille() : chosenTF.duree);
                Interval base = (chosen.Pot != null ? chosen.Pot : new Interval(chosenTF.R, chosenTF.R + dur));
                chosen.Eff = base;
            }
            // ► on alimente seulement la file des sélections ; la validation sera faite en phase 4
            cl.forceSelectFromOffer(E, chosenTF, chosen.ID_resource, chosen.Eff);
        }
    }

    /* ================================================================= */
    /*  Publication TF suivante (wish only)                               */
    /* ================================================================= */
    private void publicationTacheSuivante() {
        for (Client cl : Clients) {
            if (cl.currentTFindex >= cl.ordre.S.size()) continue;
            if (!E.is_Fixed(cl.ordre.S.get(cl.currentTFindex).ID)) continue;

            cl.currentTFindex++;
            if (cl.currentTFindex >= cl.ordre.S.size()) continue;

            TacheProduction next = cl.ordre.S.get(cl.currentTFindex);
            E.add_TF(next, next.WP); // WP tel quel
        }
    }

    /* ================================================================= */
    /*  CYCLE GLOBAL (article Fig. 3)                                     */
    /* ================================================================= */
    public void launch() {
        // 0) publication initiale
        Clients.forEach(c -> c.initialisation(E));
        System.out.println("=== État initial ===\n"+E);

        while (!E.EOTF() && nCycle < maxCycles) {
            nCycle++;
            System.out.println("\n>>> CYCLE "+nCycle+" <<<");

            // (1) Producteurs → offres TF (PP/EP) sans réserver — règle FIFO
            Supervisor.get().openAccess();
            phase2_Producteur_multiProposals();
            Supervisor.get().closeAccess();

            // (2) Mainteneurs publient PP/EP pour les TM demandées (s’il y en a, sinon NOP)
            Supervisor.get().openAccess();
            if (VirtualMaint != null) VirtualMaint.publishMaintenanceOffers(E);
            Supervisor.get().closeAccess();

            // (3) Clients : sélection (au plus 1 TF / client / cycle)
            Supervisor.get().openAccess();
            anyValidatedInThisCycle = false;
            Clients.forEach(c -> c.validation(E));
            if (!anyValidatedInThisCycle && pendingSelections.isEmpty()) forceOneByPotentialIfNeeded();
            Supervisor.get().closeAccess();

            // (4) Application centralisée des sélections (TT → TM(avant) → TF)
            Supervisor.get().openAccess();
            applySelectedValidations();
            Supervisor.get().closeAccess();

            // (5) Publication TF suivante
            Supervisor.get().openAccess();
            publicationTacheSuivante();
            Supervisor.get().closeAccess();

            if (needReplan) { needReplan = false; continue; }
            System.out.println("Fin cycle "+nCycle+" – TF restantes="+E.n_TF_non_validee());
        }

        // Filet : fixer tout ce qui reste non fixé (TF)
        for (Objet o : E.liste_TF) {
            if (o.is_fixed()) continue;
            Proposition best = E.get_Proposition(o.ID).stream().filter(p -> p.Eff != null)
                    .min(Comparator.comparingDouble(p -> p.Eff.fin)).orElse(null);
            Identifiant mac; Interval base;
            if (best != null) { mac = best.ID_resource; base = best.Eff; }
            else {
                Producteur pr = Producteurs.stream().filter(p -> p.machine.get_capability(o.TF.list_Activite) > 0).findFirst().orElse(null);
                if (pr == null) continue;
                mac = pr.machine.ID; base = new Interval(o.TF.R, o.TF.R + o.TF.duree);
            }
            Interval slot = findNextFreeSlot(mac, base, o.ID);
            E.set_Final(o.ID, new Position(o.ID, mac, slot));
        }

        // Finalisation affichage
        Mainteneurs.forEach(m -> m.lire_acceptation(E));
        Producteurs.forEach(p -> p.validation_maintenance_load(E));
        System.out.println("\n===== PLAN FINAL =====\n"+E);
    }
}
