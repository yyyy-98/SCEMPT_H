package scemptclasses;
public class Competence {

    public Identifiant ID;
    public double cout, qualite, aptitude;
    public Fonction fonction;

    public Competence(Identifiant i, double c, double q, double a, Fonction f) {
        this.ID = i;
        this.cout = c;
        this.qualite = q;
        this.aptitude = a;
        if (f != null) {
            this.fonction = new Fonction(f);
        }
    }

    public Competence(Competence c) {
        this.ID = c.ID;
        this.cout = c.cout;
        this.qualite = c.qualite;
        this.aptitude = c.aptitude;
        if (c.fonction != null) {
            this.fonction = new Fonction(c.fonction);
        }
    }
}
