package scemptclasses;

import java.util.*;
import java.util.stream.Collectors;

/**
 * **************************************************
 *                     Client
 * **************************************************
 */
public class Client {

    public OF  ordre;
    public int currentTFindex = 0;

    public Client(OF of) { this.ordre = of; this.ordre.calculerWishFB(); }

    public void initialisation(Environnement E) {
        if (!ordre.S.isEmpty()) {
            ordre.calculerWishFB();
            TacheProduction first = ordre.S.get(0);
            E.add_TF(first, first.WP);
        }
    }

    private static Interval targetFor(Proposition p, TacheProduction tf) {
        double dur = (p != null && p.Eff != null) ? p.Eff.getTaille()
                : (p != null && p.Pot != null) ? p.Pot.getTaille()
                : tf.duree;
        return new Interval(tf.WP.debut, tf.WP.debut + dur);
    }

    /** Sélection (pas de fixation) – au plus 1 TF par client et par cycle. */
    public void validation(Environnement E) {
        for (TacheProduction tf : ordre.S) {
            if (E.is_Fixed(tf.ID)) continue;
            var offers = E.get_Proposition(tf.ID);
            if (offers == null || offers.isEmpty()) return;

            final double EPS = 1e-6;

            // 1) Exact : EP=PP au début de WP
            Proposition exact = offers.stream()
                    .filter(p -> "M".equals(p.ID_resource.type))
                    .filter(p -> p.Pot != null && p.Eff != null)
                    .filter(p -> Math.abs(p.Pot.debut - tf.WP.debut) <= EPS
                              && Math.abs(p.Eff.debut - tf.WP.debut) <= EPS)
                    .findFirst().orElse(null);
            if (exact != null) {
                selectTF_forValidation(E, tf, exact);
                return;
            }

            // 2) sinon, EP=PP la plus proche du WP
            List<Proposition> effEqPot = offers.stream()
                    .filter(p -> "M".equals(p.ID_resource.type))
                    .filter(p -> p.Pot != null && p.Eff != null
                              && Math.abs(p.Pot.debut - p.Eff.debut) <= EPS
                              && Math.abs(p.Pot.fin   - p.Eff.fin)   <= EPS)
                    .collect(Collectors.toList());

            if (!effEqPot.isEmpty()) {
                Proposition best = effEqPot.stream()
                        .min(Comparator
                                .comparingDouble((Proposition p) -> Math.abs(p.Eff.debut - tf.WP.debut))
                                .thenComparingDouble(p -> p.Eff.fin)
                                .thenComparing(p -> p.ID_resource.toString()))
                        .orElse(null);

                if (best != null) {
                    selectTF_forValidation(E, tf, best);
                    return;
                }
            }
            return;
        }
    }

    /** Pousse la TF retenue dans la file des validations (SCEMPT_Algo). */
    public void selectTF_forValidation(Environnement E, TacheProduction tf, Proposition p) {
        SCEMPT_Algo.instance.queueSelectedTF(this, tf, p);
    }

    /** Utilisé par le forçage de fin de cycle : construit une pseudo-offre et sélectionne. */
    public void forceSelectFromOffer(Environnement E, TacheProduction tf, Identifiant machineId, Interval slot) {
        Proposition forced = new Proposition(tf.ID, machineId);
        forced.Pot = slot; forced.Eff = slot;
        selectTF_forValidation(E, tf, forced);
    }
}
