package scemptclasses;

import java.util.*;
/**
 * **************************************************
 */
/*            OrdreTransport (OT)                    */
/**
 * **************************************************
 */
class OrdreTransport {

    public Identifiant ID;
    public String origine, destination;
    public TacheProduction tfDeclencheuse;
    public OF ordreAssocie;
    public LinkedList<TacheTransport> listeTT = new LinkedList<>();

    public OrdreTransport(Identifiant id, String o, String d, TacheProduction tf, OF of) {
        this.ID = id;
        this.origine = o;
        this.destination = d;
        this.tfDeclencheuse = tf;
        this.ordreAssocie = of;
    }

    public void add_TT(TacheTransport tt) {
        listeTT.add(tt);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("OT ").append(ID).append(" [").append(origine)
                .append("->").append(destination).append("]\n");
        if (tfDeclencheuse != null) {
            sb.append("Declenche=").append(tfDeclencheuse);
        }
        sb.append(" (OF=").append(ordreAssocie != null ? ordreAssocie.ID : "?");
        sb.append(")\n");
        for (TacheTransport tt : listeTT) {
            sb.append("  ").append(tt).append("\n");
        }
        return sb.toString();
    }
}
