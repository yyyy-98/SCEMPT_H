package scemptclasses;

/**
 * **************************************************
 */
/*            Position                              */
/**
 * **************************************************
 */
public class Position {

    public Identifiant ID_tache;
    public Identifiant ID_resource;
    public Interval creneau;

    public Position(Identifiant t, Identifiant r, Interval c) {
        this.ID_tache = t;
        this.ID_resource = r;
        this.creneau = c;
    }

    @Override
    public String toString() {
        return "(" + creneau + "," + ID_resource + ")";
    }
}
