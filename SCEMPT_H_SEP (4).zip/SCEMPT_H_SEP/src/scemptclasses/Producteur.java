package scemptclasses;

import java.util.*;

/**
 * **************************************************
 *                  Producteur
 *  (publication d'offres TF + simulation locale EP)
 * **************************************************
 */
public class Producteur {

    public Machine machine;
    public Machine Machine_principale;

    public LinkedList<TacheProduction>   list_TF            = new LinkedList<>();
    public LinkedList<TacheProduction>   list_TF_principale = new LinkedList<>();
    public LinkedList<TacheMaintenance>  list_TM            = new LinkedList<>(); // reste vide en phase offres
    public LinkedList<Proposition>       list_prop          = new LinkedList<>();

    public Producteur(Machine M) { this.machine = new Machine(M); this.Machine_principale = new Machine(M); }

    public void activation() {
        list_TF.clear(); list_TF_principale.clear(); list_TM.clear(); list_prop.clear();
        machine = new Machine(Machine_principale);
    }

    /** PP (Pot) = au plus tôt sur planning validé ; EP (Eff) simulée sans réservation. */
    public void Position_Potentielle() {
        for (TacheProduction tf : list_TF) {
            double deb0 = tf.R;
            Interval base = new Interval(Math.max(tf.WP.debut, deb0), Math.max(tf.WP.debut, deb0) + tf.duree);
            Interval pot  = Machine_principale.get_position_disponible(base);
            for (Proposition p : list_prop) if (p.ID_tache.equals(tf.ID) && p.ID_resource.equals(machine.ID)) { p.Pot = pot; break; }
        }
    }

    /** EP locale sans aucune réservation (simulation TM "avant" uniquement). */
    public void Position_Effective() {
        list_TF.sort(Comparator
                .comparingDouble((TacheProduction tf) -> tf.WP.debut)
                .thenComparingInt(tf -> tf.ID_ordre.ordre)
                .thenComparingInt(tf -> tf.ID_tache.ordre));
        for (TacheProduction tf : new ArrayList<>(list_TF)) {
            double rel = tf.R, dur = tf.duree;
            Interval ep = computeEP_NoReservation(tf, rel, dur);
            set_eff(tf.ID, ep);
        }
    }

    public Interval computeEP_NoReservation(TacheProduction tf, double release, double adjustedDur) {
        Machine snap = new Machine(this.Machine_principale);
        Interval slot = snap.get_position_disponible(new Interval(release, release + adjustedDur));

        List<Identifiant> before = new LinkedList<>(), after = new LinkedList<>();
        snap.position_realisable(tf, slot, before, after);

        double cursor = slot.debut;
        for (Identifiant compID : before) {
            Composant comp = snap.get_Composant(compID);
            double dur = (comp != null ? comp.temps_reparation : 2.0);
            Interval tmI = new Interval(cursor, cursor + dur);
            snap.add_TM(compID, tmI);
            if (comp != null) comp.resetAfterMaintenance();
            cursor = tmI.fin;
        }
        if (!before.isEmpty()) slot = snap.get_position_disponible(new Interval(cursor, cursor + adjustedDur));
        return slot;
    }

    /** Publication SCEP (Pot/Eff) — aucune réservation. */
    public void set_Proposition(Environnement E) {
        for (Proposition p : list_prop) E.add_Proposition(p);
        list_prop.clear();
    }

    public void lire_validation(Environnement E) {
        for (TacheProduction tf : list_TF_principale) {
            if (E.is_Fixed(tf.ID)) {
                Position FP = E.get_Final(tf.ID);
                if (FP != null && FP.ID_resource.equals(machine.ID)) {
                    Machine_principale.add_TF(tf, FP.creneau);
                }
            }
        }
        list_TF.clear(); list_TF_principale.clear();
    }

    /** Nettoyage local des TM “devenues inutiles” après décisions. */
    public void validation_maintenance_load(Environnement E) {
        Iterator<TacheMaintenance> it = list_TM.iterator();
        while (it.hasNext()) {
            TacheMaintenance tm = it.next();
            Position fp = E.get_Final(tm.ID);
            if (fp == null) { it.remove(); continue; }
            if (!willNeedMachineAfter(fp.creneau.fin)) { machine.removePosition(tm.ID); it.remove(); }
        }
    }

    private boolean willNeedMachineAfter(double t) {
        for (Objet o : SCEMPT_Algo.instance.E.liste_TF) {
            if (!SCEMPT_Algo.instance.E.is_Fixed(o.ID)) continue;
            Position fp = SCEMPT_Algo.instance.E.get_Final(o.ID);
            if (fp.ID_resource.equals(machine.ID) && fp.creneau.debut >= t) return true;
        }
        for (Objet o : SCEMPT_Algo.instance.E.liste_TF) {
            if (SCEMPT_Algo.instance.E.is_Fixed(o.ID)) continue;
            if (machine.get_capability(o.TF.list_Activite) > 0 && o.TF.WP.debut <= t + 24.0) return true;
        }
        return false;
    }

    private void set_eff(Identifiant tfid, Interval i) {
        for (Proposition p : list_prop) if (p.ID_tache.equals(tfid)) p.Eff = i;
    }

    /* ——————————————————————————————————————————— */
    /*  Aides de publication (appelées par SCEMPT)  */
    /* ——————————————————————————————————————————— */
    public void publier_DeuxOffres_SCEP(Environnement E) {
        this.activation();
        List<Objet> candidats = E.liste_TF.stream()
                .filter(o -> !E.is_Fixed(o.ID))
                .sorted(Comparator.comparingDouble(o -> o.TF.WP.debut))
                .toList();

        for (Objet o : candidats) {
            TacheProduction tf0 = o.TF;
            double cap = machine.get_capability(tf0.list_Activite);
            if (cap <= 0) continue;

            double deb0 = SCEMPT_Algo.instance.earliestReadyTimeFor(tf0, machine.ID);
            double dur  = tf0.duree / Math.max(1e-9, cap);

            TacheProduction tf = new TacheProduction(tf0);
            tf.duree = dur; tf.R = deb0;

            Interval pot = Machine_principale.get_position_disponible(new Interval(Math.max(tf0.WP.debut, deb0), Math.max(tf0.WP.debut, deb0) + dur));
            Interval eff = computeEP_NoReservation(tf, deb0, dur);

            Proposition p = new Proposition(tf0.ID, machine.ID);
            p.Pot = pot; p.Eff = eff; E.add_Proposition(p);
        }
    }
}
