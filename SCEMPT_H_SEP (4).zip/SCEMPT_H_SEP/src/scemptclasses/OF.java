package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            OF                                    */
/**
 * **************************************************
 */
public class OF {

    public Identifiant ID;
    public double R;
    public double D;
    public LinkedList<TacheProduction> S = new LinkedList<>();

    public OF(Identifiant id, double r, double d) {
        this.ID = id;
        this.R = r;
        this.D = d;
    }

    public void add_TF(TacheProduction tf) {
        S.add(tf);
    }

   /* ========================================================= */
/*  1)  Calcul initial des fenêtres WP = [ES ; LF]           */
/*      méthode dite « Forward / Backwar » (Wish‑FB)        */
/* ========================================================= */
/* ====================== OF.java — calculerWishFB ====================== */
/* 1) Calcul initial des fenêtres WP0 = [ES ; LF] (Wish‑FB) — figées.   */
// === OF.java — remplacez calculerWishFB() ===
public void calculerWishFB() {
    // Passe avant : ES / EF
    double courant = R;
    for (TacheProduction tf : S) {
        tf.debut_s = courant;
        tf.R       = courant;            // ES
        tf.fin_s   = courant + tf.duree; // EF
        courant    = tf.fin_s;
    }
    // Passe arrière : LF / LS
    double back = D;
    for (int i = S.size() - 1; i >= 0; i--) {
        TacheProduction tf = S.get(i);
        tf.D  = back;                    // LF
        back  = tf.D - tf.duree;         // LS
    }
    // WP technique (évolutive) + WP objectif (figée)
    for (TacheProduction tf : S) {
        tf.WP       = new Interval(tf.R, tf.D);    // utilisée par la planif
        tf.WP_fixed = new Interval(tf.R, tf.D);    // affichée, jamais modifiée
    }
}

// === OF.java — remplacez refreshWindowsFrom(...) ===
public void refreshWindowsFrom(int first, double t0) {
    // On recale les ES/EF (R/D techniques) après une TF validée,
    // mais on NE TOUCHE PAS aux WP_fixed (objectifs client).
    double courant = t0;
    for (int i = first; i < S.size(); i++) {
        TacheProduction tf = S.get(i);
        tf.R       = Math.max(courant, tf.R);
        tf.debut_s = tf.R;
        courant    = tf.R + tf.duree;
    }
    double back = D;
    for (int i = S.size() - 1; i >= first; i--) {
        TacheProduction tf = S.get(i);
        double lf = Math.min(back, (tf.D == 0 ? back : tf.D));
        double earliestFinish = tf.R + tf.duree;
        if (lf < earliestFinish) lf = earliestFinish;
        tf.D = lf;
        back = lf - tf.duree;
    }
    for (int i = first; i < S.size(); i++) {
        S.get(i).WP = new Interval(S.get(i).R, S.get(i).D);
    }
}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ID).append(" (R=").append(R)
                .append(",D=").append(D).append(")\n");
        for (TacheProduction tf : S) {
            sb.append(tf).append("\n");
        }
        return sb.toString();
    }
}
