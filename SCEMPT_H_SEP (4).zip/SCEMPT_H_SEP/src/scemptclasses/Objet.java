package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            Objet (TF/TM/TT)                       */
/**
 * **************************************************
 */
public class Objet {

    public Identifiant ID;
    public TacheProduction TF;
    public TacheMaintenance TM;
    public TacheTransport TT;
    public Interval WP;
    public LinkedList<Proposition> Prop = new LinkedList<>();
    public Position FP;

    public Objet(Identifiant id, Interval w) {
        this.ID = id;
        this.WP = w;
    }

    public boolean is_TF() {
        return ID.type.equals("TF");
    }

    public boolean is_TM() {
        return ID.type.equals("TM");
    }

    public boolean is_TT() {
        return ID.type.equals("TT");
    }

    public boolean is_fixed() {
        return FP != null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ID);
        if (TF != null) {
            sb.append(",").append(TF.ID_ordre).append(",").append(TF.ID_tache);
        } else if (TM != null) {
            sb.append(",Mach=").append(TM.ID_Machine)
                    .append(",Comp=").append(TM.ID_Composant);
        } else if (TT != null) {
            sb.append(",").append(TT.origine).append("->").append(TT.destination);
            if (TT.reason != null) {
                sb.append(" reason=").append(TT.reason);
            }
        }
        sb.append("\t").append(WP == null ? "-" : WP).append("\t");
        if (!Prop.isEmpty()) {
            Iterator<Proposition> it = Prop.iterator();
            Proposition first = it.next();
            sb.append(first).append(" -\n");
            while (it.hasNext()) {
                sb.append("\t\t").append(it.next()).append("\n");
            }
        } else {
            sb.append("-\t");
            sb.append(is_fixed() ? FP.toString() : "-\n");
        }
        return sb.toString();
    }
}
