package scemptclasses;
import java.util.*;


/**
 * **************************************************
 */
/*            TacheProduction (TF)                  */
/**
 * **************************************************
 */
/* ========= TacheProduction.java — AJOUT champs & constructeurs ========= */
public class TacheProduction {

    public Identifiant ID;
    public Identifiant ID_ordre;
    public Identifiant ID_tache;
    public double duree;
    public double debut_s;
    public double fin_s;
    public double R;          // release dynamique / ES initial
    public double D;          // LF initial
    public Interval WP;       // pour compatibilité d’affichage
    public Interval WP0;      // <-- NOUVEAU : fenêtre "contrat" ES..LF (figée)
    public LinkedList<Identifiant> list_Activite = new LinkedList<>();
    public String siteDestination;
    public boolean needsTransport;
// === TacheProduction.java — AJOUTS ===
public Interval WP_fixed; // fenêtre "objectif client" (Wish‑FB), figée

public TacheProduction(Identifiant of, Identifiant tf, double d) {
    this.ID_ordre = of;
    this.ID_tache = tf;
    this.duree = d;
    this.needsTransport = false;
    // WP_fixed sera posée par OF.calculerWishFB()
}

public TacheProduction(TacheProduction T) {
    this.ID = T.ID;
    this.ID_ordre = T.ID_ordre;
    this.ID_tache = T.ID_tache;
    this.duree = T.duree;
    this.debut_s = T.debut_s;
    this.fin_s = T.fin_s;
    this.R = T.R;
    this.D = T.D;
    if (T.WP != null)       this.WP       = new Interval(T.WP.debut, T.WP.fin);
    if (T.WP_fixed != null) this.WP_fixed = new Interval(T.WP_fixed.debut, T.WP_fixed.fin);
    this.siteDestination = T.siteDestination;
    this.list_Activite.addAll(T.list_Activite);
    this.needsTransport = T.needsTransport;
}


    public void add_activite(Identifiant a) {
        list_Activite.add(a);
    }

    @Override
    public String toString() {
        return "(" + ID_ordre + "-" + ID_tache + ",dur=" + duree
                + ",WP0=" + (WP0 != null ? WP0 : "null") + ")";
    }
}
