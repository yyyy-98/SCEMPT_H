package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            Pathfinder                             */
/**
 * **************************************************
 */
class Pathfinder {

    public Map<String, Map<String, Double>> graphe = new HashMap<>();

    public Pathfinder() {
        Map<String, Double> fromS0 = new HashMap<>();
        fromS0.put("S2", 6.0);
        graphe.put("S0", fromS0);
        Map<String, Double> fromS1 = new HashMap<>();
        fromS1.put("S2", 5.0);
        graphe.put("S1", fromS1);
        Map<String, Double> fromS2 = new HashMap<>();
        fromS2.put("S0", 6.0);
        fromS2.put("S1", 5.0);
        graphe.put("S2", fromS2);
    }

    public List<String> calculerChemin(String orig, String dest) {
        if (!graphe.containsKey(orig) || !graphe.containsKey(dest)) {
            return new ArrayList<>();
        }
        if (graphe.get(orig).containsKey(dest)) {
            return Arrays.asList(orig, dest);
        }
        for (String pivot : graphe.keySet()) {
            if (!pivot.equals(orig) && graphe.get(orig).containsKey(pivot)
                    && graphe.get(pivot).containsKey(dest)) {
                return Arrays.asList(orig, pivot, dest);
            }
        }
        return new ArrayList<>();
    }

    public LinkedList<TacheTransport> genererTachesTransport(String orig, String dest, double rel, String reason) {
        LinkedList<TacheTransport> ret = new LinkedList<>();
        List<String> path = calculerChemin(orig, dest);
        if (path.size() < 2) {
            return ret;
        }
        double courant = rel;
        for (int i = 0; i < path.size() - 1; i++) {
            String o = path.get(i);
            String d = path.get(i + 1);
            Double dist = graphe.get(o).get(d);
            if (dist == null) {
                continue;
            }
            TacheTransport tt = new TacheTransport(o, d, dist, courant, reason);
            tt.segment = i;
            ret.add(tt);
            courant += dist;
        }
        return ret;
    }
}