package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            TacheMaintenance (TM)                 */
/**
 * **************************************************
 */
public class TacheMaintenance {

    public Identifiant ID;
    public Identifiant ID_Machine;
    public Identifiant ID_Composant;
    public double duree;
    public double R;
    public LinkedList<Identifiant> list_Activite = new LinkedList<>();

    public TacheMaintenance(Identifiant mach, Identifiant comp, double dur, double rel) {
        this.ID_Machine = mach;
        this.ID_Composant = comp;
        this.duree = dur;
        this.R = rel;
    }

    public TacheMaintenance(TacheMaintenance TM) {
        this.ID = TM.ID;
        this.ID_Machine = TM.ID_Machine;
        this.ID_Composant = TM.ID_Composant;
        this.duree = TM.duree;
        this.R = TM.R;
        this.list_Activite.addAll(TM.list_Activite);
    }

    public void add_activite(Identifiant c) {
        list_Activite.add(c);
    }

    @Override
    public String toString() {
        return "(TM on " + ID_Machine + "-" + ID_Composant + ")";
    }
}