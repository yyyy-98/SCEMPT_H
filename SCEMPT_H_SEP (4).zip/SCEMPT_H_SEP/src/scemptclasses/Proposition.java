package scemptclasses;

/**
 * **************************************************
 */
/*            Proposition                           */
/**
 * **************************************************
 */
public class Proposition {

    public Identifiant ID_tache;     // TF,TM,TT
    public Identifiant ID_resource;  // ex. Machine, Mainteneur ou Transporter
    public Interval Pot; // potentiel
    public Interval Eff; // effectif

    public Proposition(Identifiant tid, Identifiant rid) {
        this.ID_tache = tid;
        this.ID_resource = rid;
    }

    @Override
    public String toString() {
        return "(" + (Pot != null ? Pot : "-") + "," + (Eff != null ? Eff : "-")
                + "," + ID_resource + ")";
    }
}