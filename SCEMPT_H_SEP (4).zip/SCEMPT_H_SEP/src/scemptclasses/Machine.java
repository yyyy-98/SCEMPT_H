package scemptclasses;
import java.util.*;  // en haut du fichier
import java.util.stream.Collectors;

/**
 * **************************************************
 */
/*            Machine                                */
/**
 * **************************************************
 */
public class Machine {

    public Identifiant ID;
    public boolean transportable;
    public LinkedList<Composant> liste_Composant = new LinkedList<>();
    public LinkedList<Competence> liste_Competence = new LinkedList<>();
    public LinkedList<Position> planning = new LinkedList<>();
/* ------------------------------------------------------------------ */
/*  Politique préventive fondée sur la Remaining Useful Life          */
/* ------------------------------------------------------------------ */
public static final double RUL_BEFORE =  2.0;   // h  – TM avant TF
public static final double RUL_AFTER  =  5.0;   // h  – TM après TF

    public Machine(Identifiant id, boolean t) {
        this.ID = id;
        this.transportable = t;
    }

    public Machine(Machine M) {
        this.ID = M.ID;
        this.transportable = M.transportable;
        for (Composant c : M.liste_Composant) {
            liste_Composant.add(new Composant(c));
        }
        for (Competence cc : M.liste_Competence) {
            liste_Competence.add(new Competence(cc));
        }
        for (Position p : M.planning) {
            planning.add(p);
        }
    }
/** Vérifie la disponibilité d'une fonction pendant [tStart ; tStart+dur]. */
// ★ NEW
/** Renvoie vrai si la fonction f dispose des composants requis pendant [tStart ; tStart+dur]. */
/** Retourne vrai si la fonction «f» peut s’exécuter pendant «dur». */
/* Vérifie la disponibilité PHM (RUL) pour la fonction “f” pendant “dur” */
public boolean fonctionDisponible(Fonction f, double dur) {
    List<Composant> comps = f.liste_composant.stream()
            .map(this::get_Composant)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

    if (f.logique == LogicType.AND) {
        return comps.stream().allMatch(c -> !c.willFail(dur));
    } else {
        return comps.stream().anyMatch(c -> !c.willFail(dur));
    }
}
// === Machine — AJOUT helper interne ===
private static final class Risk {
    final double preRUL;       // RUL avant la TF
    final boolean willFail;    // dépasse λ pendant la TF
    final double pSlot;        // probabilité de panne pendant le slot
    final double usageRatio;   // % d'usure actuelle (temps_marche / lambda)
    Risk(double preRUL, boolean willFail, double pSlot, double usageRatio) {
        this.preRUL = preRUL; this.willFail = willFail; this.pSlot = pSlot; this.usageRatio = usageRatio;
    }
}
private static void addUnique(List<Identifiant> list, Identifiant id) {
    if (list.stream().noneMatch(x -> x.equals(id))) list.add(id);
}


    public void add_Composant(Composant c) {
        liste_Composant.add(new Composant(c));
    }

    public void add_Competence(Competence c) {
        liste_Competence.add(new Competence(c));
    }

    public void add_to_planning(Position p) {
        planning.add(p);
        trier_planning();
    }

    public void trier_planning() {
        Position[] arr = planning.toArray(new Position[0]);
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].creneau.debut < arr[min].creneau.debut) {
                    min = j;
                }
            }
            if (min != i) {
                Position tmp = arr[min];
                arr[min] = arr[i];
                arr[i] = tmp;
            }
        }
        planning.clear();
        planning.addAll(Arrays.asList(arr));
    }

    public boolean chevaucher(Interval i1, Interval i2) {
        if (i1.debut >= i2.fin) {
            return false;
        }
        if (i1.fin <= i2.debut) {
            return false;
        }
        return true;
    }
    /**
 * Renvoie le premier créneau libre d’au moins « duree » unités situé
 * entièrement dans [win.debut ; win.fin], ou null si aucun.
 */
/* Renvoie le 1er créneau libre ≥ win.debut de durée “duree”, contenu dans [win.debut ; +∞), en sautant les TM */
// Variante bornée : null si aucun trou entièrement dans la fenêtre
public Interval findFirstGapInWindow(Interval win, double duree) {
    trier_planning();
    double start = win.debut, limit = win.fin;
    for (Position pos : planning) {
        if (pos.creneau.debut >= limit) break;
        if (pos.creneau.fin <= start) continue;
        if (start + duree <= Math.min(pos.creneau.debut, limit))
            return new Interval(start, start + duree);
        start = Math.max(start, pos.creneau.fin);
        if (start + duree > limit) return null;
    }
    return (start + duree <= limit) ? new Interval(start, start + duree) : null;
}

    public Interval get_position_disponible(Interval I) {
    trier_planning();
    double duree = I.getTaille();
    double start = I.debut;

    for (Position pos : planning) {
        if (start + duree <= pos.creneau.debut) return new Interval(start, start + duree);
        if (chevaucher(new Interval(start, start + duree), pos.creneau)) {
            start = pos.creneau.fin;  // saute TF/TM
        }
    }
    return new Interval(start, start + duree);
}

   /**  Teste la faisabilité SANS repousser la TF ; la maintenance se fera après. */
/** Teste la faisabilité d’une TF dans le créneau `test`.
 *  Remplit `compCrit` avec les composants qu’il faudra absolument réparer.      */
/**  Retourne vrai si la TF peut s’exécuter dans « slot ».  
 *   Remplit « critBefore » et « critAfter » :
 *      • si risque ≥ RISK_BEFORE_START  →  TM avant TF
 *      • sinon si risque ≥ RISK_AFTER_START →  TM après TF
 */
/**  Analyse PHM et sépare les composants critiques :  
 *    • critBefore : TM obligatoire avant la TF  
 *    • critAfter  : TM potentielle juste après la TF                */
/**
 * Analyse la faisabilité + détecte les composants à maintenir.
 * @param before  liste des composants à réparer avant la TF
 * @param after   liste des composants à réparer juste après la TF
 * @return        true si le créneau ne chevauche rien dans le planning
 */
/**
 * Analyse PHM sur le créneau “slot” pour la TF “tf”.
 * Remplit :
 *   before : composants à maintenir avant la TF (RUL avant ≤ RUL_BEFORE)
 *   after  : composants à maintenir juste après (RUL après ≤ RUL_AFTER)
 * Retourne false si le créneau chevauche déjà le planning machine.
 */
/**
 * Analyse PHM multi-critères sur le créneau “slot” pour la TF “tf”.
 * Remplit :
 *   before : composants à maintenir AVANT (RUL trop faible / risque élevé / fail during)
 *   after  : composants à maintenir APRES (préventif, risque, RUL après faible)
 * Retourne false si le créneau chevauche déjà le planning machine.
 */
// ===== Machine.position_realisable — REMPLACER =====
public boolean position_realisable(TacheProduction tf,
                                   Interval slot,
                                   List<Identifiant> before,
                                   List<Identifiant> after) {
    // 0) Interdit tout chevauchement avec le planning machine
    for (Position p : planning) if (chevaucher(slot, p.creneau)) return false;

    // 1) Analyse PHM par fonctions/compétences
    for (Identifiant act : tf.list_Activite) {
        Competence comp = get_Competence(act);
        if (comp == null || comp.fonction == null) return false;

        for (Identifiant cid : comp.fonction.liste_composant) {
            Composant c = get_Composant(cid);
            if (c == null) continue;

            double durTF   = tf.duree;                  // charge de la TF
            double afterTF = c.temps_marche + durTF;    // usage après TF

            // (A) TM AVANT si la TF dépasserait le seuil du composant
            if (afterTF > c.seuil + 1e-9 || c.willCrossThreshold(durTF)) {
                if (before.stream().noneMatch(cid::equals)) before.add(cid);
                continue; // déjà classé "avant"
            }

            // (B) Sinon, TM APRES si on se rapproche du seuil sans le dépasser
            //     + seulement si la machine sera réutilisée prochainement
            boolean nearThreshold = (c.seuil - afterTF) <= SCEMPT_Algo.PHM_AFTER_MARGIN;
            if (nearThreshold) {
                boolean needLater = false;

                // i) TF déjà fixées plus tard sur cette machine
                for (Objet o : SCEMPT_Algo.instance.E.liste_TF) {
                    if (!SCEMPT_Algo.instance.E.is_Fixed(o.ID)) continue;
                    Position fp = SCEMPT_Algo.instance.E.get_Final(o.ID);
                    if (fp != null && fp.ID_resource.equals(this.ID) && fp.creneau.debut >= slot.fin) {
                        needLater = true; break;
                    }
                }
                // ii) ou TF non fixées compatibles avec fenêtre débutant bientôt
                if (!needLater) {
                    for (Objet o : SCEMPT_Algo.instance.E.liste_TF) {
                        if (SCEMPT_Algo.instance.E.is_Fixed(o.ID)) continue;
                        if (get_capability(o.TF.list_Activite) > 0 &&
                            o.TF.WP.debut <= slot.fin + SCEMPT_Algo.PHM_AFTER_LOOKAHEAD) {
                            needLater = true; break;
                        }
                    }
                }

                if (needLater && afterTF <= c.seuil + 1e-9) {
                    if (after.stream().noneMatch(cid::equals)) after.add(cid);
                }
            }
        }
    }
    return true;
}
// Machine.java — AJOUTEZ dans la classe
public List<Fonction> fonctionsPourTF(TacheProduction tf) {
    LinkedHashSet<Fonction> set = new LinkedHashSet<>();
    for (Identifiant act : tf.list_Activite) {
        Competence c = get_Competence(act);
        if (c != null && c.fonction != null) set.add(c.fonction);
    }
    return new ArrayList<>(set);
}

// === Machine.java — AJOUT COMPLET (coller dans la classe) ===



    public Competence get_Competence(Identifiant id) {
        for (Competence c : liste_Competence) {
            if (c.ID.equals(id)) {
                return c;
            }
        }
        return null;
    }

    public Composant get_Composant(Identifiant cid) {
        for (Composant c : liste_Composant) {
            if (c.ID.equals(cid)) {
                return c;
            }
        }
        return null;
    }

    public LinkedList<Composant> get_Composant_inCompetences(LinkedList<Identifiant> acts) {
        LinkedList<Composant> ret = new LinkedList<>();
        for (Identifiant a : acts) {
            Competence c = get_Competence(a);
            if (c != null && c.fonction != null) {
                for (Identifiant cid : c.fonction.liste_composant) {
                    Composant cc = get_Composant(cid);
                    if (cc != null && !ret.contains(cc)) {
                        ret.add(cc);
                    }
                }
            }
        }
        return ret;
    }

    public double get_capability(LinkedList<Identifiant> acts) {
        double cap = 0;
        for (Identifiant a : acts) {
            Competence c = get_Competence(a);
            if (c == null) {
                return 0;
            }
            if (c.aptitude > cap) {
                cap = c.aptitude;
            }
        }
        return cap;
    }

public void add_TF(TacheProduction tf, Interval slot) {

    Position p = new Position(tf.ID, this.ID, slot);
    add_to_planning(p);

    /* mise à jour compteur d’utilisation -------------------------- */
    get_Composant_inCompetences(tf.list_Activite)
        .forEach(c -> c.consume(tf.duree));
}

    public void removePosition(Identifiant tid) {
        planning.removeIf(p -> p.ID_tache.equals(tid));
        for (Composant c : liste_Composant) {
            c.remove_from_planning(tid);
        }
    }

   // Machine.java — remplacer l’ancienne méthode + ajouter un overload

public void add_TM(Identifiant tmID, Identifiant compID, Interval i) {
    Position p = new Position(tmID, this.ID, i);
    add_to_planning(p);
    Composant c = get_Composant(compID);
    if (c != null) c.add_to_planning(p);
}

// Overload pour usages « clone local » (ancienne signature)
public void add_TM(Identifiant compID, Interval i) {
    add_TM(new Identifiant("TM_SIM", -1), compID, i);
}


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Machine").append(ID).append(": ");
        for (Position p : planning) {
            sb.append("[").append(p.ID_tache).append(",").append(p.creneau).append("]");
        }
        return sb.toString();
    }
}
