package scemptclasses;

import java.util.*;

/*            TacheTransport (TT)                   */
/**
 * **************************************************
 */
public class TacheTransport {

    public Identifiant ID;
    public Identifiant ID_transport;
    public String origine, destination;
    public double duree;
    public double R;
    public Identifiant ID_OT;
    public String reason;
    public LinkedList<Identifiant> list_Activite = new LinkedList<>();
    public int segment;

    public TacheTransport(String o, String d, double dur, double rel) {
        this.origine = o;
        this.destination = d;
        this.duree = dur;
        this.R = rel;
        this.segment = 0;
    }

    public TacheTransport(String o, String d, double dur, double rel, String reas) {
        this(o, d, dur, rel);
        this.reason = reas;
    }

    public TacheTransport(TacheTransport T) {
        this.ID = T.ID;
        this.ID_transport = T.ID_transport;
        this.origine = T.origine;
        this.destination = T.destination;
        this.duree = T.duree;
        this.R = T.R;
        this.ID_OT = T.ID_OT;
        this.reason = T.reason;
        this.segment = T.segment;
        this.list_Activite.addAll(T.list_Activite);
    }

    public void add_activite(Identifiant a) {
        list_Activite.add(a);
    }

    @Override
    public String toString() {
        return "(TT: " + origine + "->" + destination
                + ", dur=" + duree
                + (reason != null ? " (" + reason + ")" : "")
                + (ID_OT != null ? " [OT=" + ID_OT + "]" : "")
                + ", seg=" + segment + ")";
    }
}