package scemptclasses;
import java.util.*;
/**
 * **************************************************
 */
/*            Interval                               */
/**
 * **************************************************
 */
public class Interval {

    public double debut;
    public double fin;

    public Interval(double d, double f) {
        this.debut = d;
        this.fin = f;
    }

    public double getTaille() {
        return fin - debut;
    }
public static String format(double v) {
    return String.format(Locale.US, "%.2f", v);   // 2 décimales
}
    @Override
    public String toString() {
    return "[" + format(debut) + "," + format(fin) + "]";
    
}
}
