package scemptclasses;

import java.util.List;

/**
 * VirtualMaintainer : passerelle Maintenance (SCEMPT ↔ SCEM).
 * Version non-intrusive : déroule la phase où les mainteneurs publient leurs offres TM.
 */
public class VirtualMaintainer {

    private final List<Mainteneur> mainteneurs;

    public VirtualMaintainer(List<Mainteneur> mainteneurs) {
        this.mainteneurs = mainteneurs;
    }

    /** Phase maintenance : collecte TM -> PP/EP -> publication (Pot=Eff) */
    public void publishMaintenanceOffers(Environnement E) {
        if (mainteneurs == null) return;
        for (Mainteneur m : mainteneurs) {
            m.activation();
            m.get_TM(E);
            m.trier();
            m.Position_Potentielle();
            m.Position_Effective();
            m.set_Proposition(E);
        }
    }
}
