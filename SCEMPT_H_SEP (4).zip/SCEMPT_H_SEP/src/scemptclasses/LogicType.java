package scemptclasses;
import java.util.*;
import java.util.stream.Collectors;  // en haut du fichier
public enum LogicType{
AND,
OR

}