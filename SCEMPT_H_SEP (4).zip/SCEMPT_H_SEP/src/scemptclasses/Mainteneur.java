package scemptclasses;
import java.util.*;

public class Mainteneur {

    public Identifiant ID;
    public LinkedList<Competence> liste_Competence = new LinkedList<>();
    public LinkedList<TacheMaintenance> list_TM = new LinkedList<>();
    public LinkedList<TacheMaintenance> list_TM_principale = new LinkedList<>();
    public LinkedList<Proposition> list_prop = new LinkedList<>();
    public LinkedList<Position> planning = new LinkedList<>();
    public LinkedList<Position> planning_principale = new LinkedList<>();

    public Mainteneur(Identifiant id) {
        this.ID = id;
    }

    public Mainteneur(Mainteneur M) {
        this.ID = M.ID;
        for (Competence c : M.liste_Competence) {
            add_Competence(c);
        }
        for (Position p : M.planning) {
            add_to_planning(p);
        }
        for (Position p : M.planning_principale) {
            add_to_planning_principale(p);
        }
        for (Proposition pr : M.list_prop) {
            list_prop.add(pr);
        }
        for (TacheMaintenance tm : M.list_TM) {
            list_TM.add(tm);
        }
    }

    public void add_Competence(Competence c) {
        liste_Competence.add(new Competence(c));
    }
    public void remove_orphan_TM(Environnement E) {
    planning_principale.removeIf(pos ->
        !E.liste_TM.stream().anyMatch(o -> pos.ID_tache.equals(o.ID)));
    planning.clear();
    planning.addAll(planning_principale);
}


    public double get_capability(LinkedList<Identifiant> acts) {
        double cap = 0;
        for (Identifiant a : acts) {
            Competence c = get_Competence(a);
            if (c == null) {
                return 0;
            }
            if (c.aptitude > cap) {
                cap = c.aptitude;
            }
        }
        return cap;
    }

    public Competence get_Competence(Identifiant id) {
        for (Competence c : liste_Competence) {
            if (c.ID.equals(id)) {
                return c;
            }
        }
        return null;
    }

    public void add_to_planning(Position p) {
        planning.add(p);
        trier_planning(planning);
    }

    public void add_to_planning_principale(Position p) {
        planning_principale.add(p);
        trier_planning(planning_principale);
    }

    public void activation() {
        planning.clear();
        planning.addAll(planning_principale);
        trier_planning(planning);
        initialisation();
    }

    public void initialisation() {
        list_TM.clear();
        list_TM_principale.clear();
        list_prop.clear();
    }

    public void get_TM(Environnement E) {
        for (Objet o : E.liste_TM) {
            if (!E.is_Fixed(o.ID)) {
                double cap = get_capability(o.TM.list_Activite);
                if (cap != 0) {
                    TacheMaintenance copy = new TacheMaintenance(o.TM);
                    copy.duree = copy.duree / cap;
                    list_TM.add(copy);
                    list_TM_principale.add(copy);
                }
            }
        }
    }

    public void FIFO() {
        TacheMaintenance[] arr = list_TM.toArray(new TacheMaintenance[0]);
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].R < arr[min].R) {
                    min = j;
                }
            }
            if (min != i) {
                TacheMaintenance tmp = arr[min];
                arr[min] = arr[i];
                arr[i] = tmp;
            }
        }
        list_TM.clear();
        list_TM.addAll(Arrays.asList(arr));
    }

    public void trier() {
        FIFO();
        list_prop.clear();
        for (TacheMaintenance tm : list_TM) {
            Proposition p = new Proposition(tm.ID, ID);
            list_prop.add(p);
        }
    }

    public void Position_Potentielle() {
        for (TacheMaintenance tm : list_TM) {
            double t = tm.R;
            Interval I = new Interval(t, t + tm.duree);
            I = get_position_disponible(planning, I);
            set_pot(tm.ID, I);
        }
    }

    /**
     * Retourne le premier créneau libre à la fois pour le mainteneur et pour
     * la machine ciblée.
     */
    private Interval get_common_slot(Machine mach, double start, double dur) {
    mach.trier_planning();
    trier_planning(planning);
    double s = start;
    while (true) {
        Interval cand = new Interval(s, s + dur);
        boolean clash = false;
        for (Position p : planning) {
            if (chevaucher(cand, p.creneau)) { s = p.creneau.fin; clash = true; break; }
        }
        if (clash) continue;
        for (Position p : mach.planning) {
            if (chevaucher(cand, p.creneau)) { s = p.creneau.fin; clash = true; break; }
        }
        if (!clash) return cand;
    }
}

    public void Position_Effective() {
    // ► ICI : on calcule EP (=Pot) pour chaque TM, mais on ne fixe pas dans l'environnement
    for (TacheMaintenance tm : list_TM) {
        double t = tm.R;

        // Trou commun mainteneur + machine (sans rien figer)
        Producteur prod = SCEMPT_Algo.instance.Producteurs.stream()
                .filter(pr -> pr.machine.ID.equals(tm.ID_Machine))
                .findFirst().orElse(null);

        Interval I = (prod != null)
                ? get_common_slot(prod.machine, t, tm.duree)
                : get_position_disponible(planning, new Interval(t, t + tm.duree));

        // Renseigne EP/PP dans la proposition locale
        Proposition my = list_prop.stream()
                .filter(p -> p.ID_tache.equals(tm.ID))
                .findFirst().orElse(null);
        if (my == null) {
            my = new Proposition(tm.ID, ID);
            list_prop.add(my);
        }
        my.Pot = I;
        my.Eff = I;

        // IMPORTANT : pas de set_Final ici, pas d'ajout dans planning machine
        // La validation sera faite plus tard par le Producer (SCEMPT_Algo.applySelectedValidations).
    }
}


    public void set_pot(Identifiant tid, Interval i) {
        for (Proposition p : list_prop) {
            if (p.ID_tache.equals(tid)) {
                p.Pot = i;
            }
        }
    }

    public void set_eff(Identifiant tid, Interval i) {
        for (Proposition p : list_prop) {
            if (p.ID_tache.equals(tid)) {
                p.Eff = i;
            }
        }
    }

    public void set_Proposition(Environnement E) {
        for (Proposition p : list_prop) {
            if (E.is_Fixed(p.ID_tache)) {
                continue;               // déjà fixée ⇒ inutile de publier
            }
            E.add_Proposition(p);
        }
        list_prop.clear();
        activation();
    }

    public void lire_acceptation(Environnement E) {
        planning.clear();
        planning_principale.clear();
        for (Objet o : E.liste_TM) {
            if (E.is_Fixed(o.ID)) {
                add_to_planning_principale(o.FP);
                Producteur pr = SCEMPT_Algo.instance.Producteurs.stream()
                        .filter(p -> p.machine.ID.equals(o.TM.ID_Machine))
                        .findFirst().orElse(null);
                if (pr != null) {
                  pr.machine.add_TM(o.TM.ID, o.TM.ID_Composant, o.FP.creneau);
pr.Machine_principale.add_TM(o.TM.ID, o.TM.ID_Composant, o.FP.creneau);
                }
            }
        }
    }

    public void lire_validation(Environnement E) {
        planning.clear();
        planning_principale.clear();
        for (Objet o : E.liste_TM) {
            if (o.FP != null) {
                add_to_planning_principale(o.FP);
            }
        }
    }

    public Interval get_position_disponible(LinkedList<Position> plan, Interval I) {
        for (Position p : plan) {
            if (chevaucher(I, p.creneau)) {
                double t = p.creneau.fin;
                I = new Interval(t, t + I.getTaille());
            }
        }
        return I;
    }

    public boolean chevaucher(Interval i1, Interval i2) {
        if (i1.debut >= i2.fin) {
            return false;
        }
        if (i1.fin <= i2.debut) {
            return false;
        }
        return true;
    }

    public void trier_planning(LinkedList<Position> plan) {
        plan.removeIf(Objects::isNull);
        Position[] arr = plan.toArray(new Position[0]);
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].creneau.debut < arr[min].creneau.debut) {
                    min = j;
                }
            }
            if (min != i) {
                Position tmp = arr[min];
                arr[min] = arr[i];
                arr[i] = tmp;
            }
        }
        plan.clear();
        plan.addAll(Arrays.asList(arr));
    }
}
