package scemptclasses;
import java.util.*;
import java.util.stream.Collectors;  // en haut du fichier
/**
 * **************************************************
 */
/*            TransporteurVirtuel                    */
/**
 * **************************************************
 */
public class TransporteurVirtuel {

    public String ID = "Virtual";
    public LinkedList<TacheTransport> list_TT = new LinkedList<>();
    public LinkedList<TacheTransport> list_TT_principale = new LinkedList<>();
    public LinkedList<Proposition> list_prop = new LinkedList<>();
    public LinkedList<Transporter> transporters = new LinkedList<>();

    public void addTransporters(LinkedList<Transporter> t) {
        transporters = t;
    }

    public void activation() {
        list_TT.clear();
        list_TT_principale.clear();
        list_prop.clear();
    }

    public void initialisation() {
        activation();
    }

    public void get_TT(Environnement E) {
        // On collecte d’abord tous les TT non-fixés

        List<Objet> pending = E.liste_TT.stream()
                .filter(o -> !E.is_Fixed(o.ID)) // <— on appelle is_Fixed, pas is_fixed
                // On les trie d’abord par OT.ordre (TF dans l’ordre de publication),
                // puis par segment (pour l’ordre interne de chaque chaîne de transport).
                .sorted(Comparator
                        .comparingInt((Objet o) -> o.TT.ID_OT.ordre)
                        .thenComparingInt(o -> o.TT.segment))
                .collect(Collectors.toList());

        // On reconstruit nos listes internes dans cet ordre
        list_TT.clear();
        list_TT_principale.clear();
        for (Objet o : pending) {
            TacheTransport copy = new TacheTransport(o.TT);
            list_TT.add(copy);
            list_TT_principale.add(copy);
        }
    }

    public void set_Proposition(Environnement E) {
        for (Proposition p : list_prop) {
            E.add_Proposition(p);
        }
        list_prop.clear();
    }

    public void trier() {
        TacheTransport[] arr = list_TT.toArray(new TacheTransport[0]);
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].R < arr[min].R) {
                    min = j;
                }
            }
            if (min != i) {
                TacheTransport tmp = arr[min];
                arr[min] = arr[i];
                arr[i] = tmp;
            }
        }
        list_TT.clear();
        list_TT.addAll(Arrays.asList(arr));
        list_prop.clear();
        for (TacheTransport tt : list_TT) {
            for (Transporter tr : transporters) {
                if (tr.peutTransporter(tt)) {
                    Proposition p = new Proposition(tt.ID, tr.ID);
                    list_prop.add(p);
                }
            }
        }
    }

    public void Position_Potentielle() {
        for (TacheTransport tt : list_TT) {
            Interval I = new Interval(tt.R, tt.R + tt.duree);
            for (Proposition pr : list_prop) {
                if (pr.ID_tache.equals(tt.ID)) {
                    pr.Pot = I;
                }
            }
        }
    }
    // Dans Transporter (ou VirtualTrans.Position_Effective quand tu poses un TT)
private Interval firstFeasibleForTT(Environnement E, Interval base) {
    double s = base.debut, d = base.getTaille();
    while (true) {
        Interval cand = new Interval(s, s + d);
        if (E.resourceDisponible(new Identifiant(this.ID, 0), cand)) return cand;
        // petit incrément pour éviter boucle infinie
        s = s + 0.01;
    }
}


    public void Position_Effective() {
        // map pour chaîner les segments d'un même OT
        Map<Identifiant, Double> lastFinishByOT = new HashMap<>();

        for (TacheTransport tt : list_TT) {
            // 1) CHAÎNAGE : repousser tt.R après la fin effective du segment précédent
            if (tt.ID_OT != null && tt.segment > 0) {
                Double finPrev = lastFinishByOT.get(tt.ID_OT);
                if (finPrev != null && tt.R < finPrev) {
                    tt.R = finPrev;
                }
            }

            // 2) calcul de la proposition effective sur le transporteur choisi
            double t0 = tt.R;
            Interval I = new Interval(t0, t0 + tt.duree);
            for (Proposition prop : list_prop) {
                if (!prop.ID_tache.equals(tt.ID)) {
                    continue;
                }
                for (Transporter tr : transporters) {
                    if (!tr.ID.equals(prop.ID_resource)) {
                        continue;
                    }

Interval eff = firstFeasibleForTT(SCEMPT_Algo.instance.E, I);                    // on s'assure de ne pas reculer sous tt.R
                    if (eff.debut < tt.R) {
                        eff = new Interval(tt.R, tt.R + eff.getTaille());
                    }
                    prop.Eff = eff;
                    tr.add_TT(tt, eff);

                    // 3) on mémorise la fin effective pour le chaînage du segment suivant
                    lastFinishByOT.put(tt.ID_OT, eff.fin);
                    break;
                }
            }
        }
    }

    public void acceptation(Environnement E) {
        for (TacheTransport tt : list_TT_principale) {
            if (!E.is_Fixed(tt.ID)) {
                LinkedList<Proposition> PP = E.get_Proposition(tt.ID);
                if (!PP.isEmpty()) {
                    double bestFin = Double.POSITIVE_INFINITY;
                    Proposition best = null;
                    for (Proposition p : PP) {
                        if (p.Eff != null && p.Eff.fin < bestFin) {
                            bestFin = p.Eff.fin;
                            best = p;
                        }
                    }
                    if (best != null) {
                        E.set_Final(tt.ID, new Position(tt.ID, best.ID_resource, best.Eff));
                    }
                }
            }
        }
    }

    public void lire_validation(Environnement E) {
        list_TT.clear();
        list_TT_principale.clear();
    }
}