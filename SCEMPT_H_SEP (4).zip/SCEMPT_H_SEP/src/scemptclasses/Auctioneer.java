package scemptclasses;
import java.util.*;  // en haut du fichier
import java.util.stream.Collectors;
/* ===================================================== */
/*                  Auctioneer (enchères)                */
/* ===================================================== */

/* =================================================================== */
/*   Auctioneer 2.0  – choisit le producteur qui termine le plus tôt   */
/* =================================================================== */

class Auctioneer {

    private final Environnement env;
    private final List<Producteur> prodList;

    /** Vainqueur et créneau retenu →  TF.ID  ➜  (Machine.ID , Interval) */
    private final Map<Identifiant, Map.Entry<Identifiant, Interval>> win = new HashMap<>();

    public Auctioneer(Environnement env, List<Producteur> prods) {
        this.env      = env;
        this.prodList = prods;
    }

    /* ---------------------- appelé chaque cycle --------------------- */
    /* ======================================================================
 *  runAuctions : mène une enchère pour chaque TF non encore fixée.
 *                – calcule la date « au plus tôt » du producteur,
 *                  transport inclus,
 *                – retient le couple (machine, créneau) qui termine
 *                  le plus tôt.
 *  Le résultat est mémorisé dans      win : Map< TF.ID , (Machine.ID , Interval) >
 * ====================================================================== */
/* ====================================================================
 *  runAuctions – sélectionne, pour chaque TF publiée et non fixée,
 *                le producteur qui TERMINE le plus tôt.
 *
 *  ► Les TF sont prises dans l’ordre chronologique de leur fenêtre WP
 *    (ou de leur date R) ; après chaque adjudication le créneau est
 *    immédiatement bloqué dans un clone du planning machine, de sorte
 *    que les tâches suivantes ne puissent pas chevaucher.
 * ==================================================================== */
/* ======================================================================= */
/*   Auctioneer 2.2 :                                                     */
/*       – choisit la fin la plus tôt (transport inclus)                   */
/*       – toujours un vainqueur ; si aucun créneau dans WP,              */
/*          il prend le 1er possible APRES WP.fin                          */
/* ======================================================================= */
/* ======================================================================= */
/*   Auctioneer 2.2  –  fin la plus tôt (transport inclus)                 */
/*   – garantit toujours un vainqueur                                      */
/*   – réserve tout de suite le créneau dans un « shadow » planning        */
/* ======================================================================= */
public void runAuctions() {

    win.clear();

    /* 1) copie de travail des plannings producteurs --------------------- */
    Map<Identifiant, Machine> shadow =
        prodList.stream()
                .collect(Collectors.toMap(p -> p.machine.ID,
                                          p -> new Machine(p.machine)));

    /* 2) TF à traiter triées par WP.debut ------------------------------ */
    List<Objet> queue = env.liste_TF.stream()
                          .filter(o -> !env.is_Fixed(o.ID))
                          .sorted(Comparator.comparingDouble(o -> o.TF.WP.debut))
                          .collect(Collectors.toList());

    /* 3) enchères ------------------------------------------------------- */
    for (Objet obj : queue) {

        TacheProduction tf = obj.TF;
        String sitePrev   = SCEMPT_Algo.siteOfPreviousTF(tf);   // "" si aucune

        double       bestEnd = Double.POSITIVE_INFINITY;
        Identifiant  bestMac = null;
        Interval     bestSol = null;

        for (Producteur pr : prodList) {

            Machine mc = shadow.get(pr.machine.ID);
            double  cap = mc.get_capability(tf.list_Activite);
            if (cap == 0) continue;

            String siteM = SCEMPT_Algo.detectSiteMachine(mc.ID);
            double tTrav = SCEMPT_Algo.instance.travelTime(sitePrev, siteM);

            double deb0 = Math.max(tf.R,
                           SCEMPT_Algo.instance.dateFinPrecedente(tf) + tTrav);
            Interval wish = new Interval(deb0, deb0 + tf.duree / cap);

            /* trou au plus tôt – même s’il déborde du WP */
            Interval slot = mc.get_position_disponible(wish);

            if (slot.fin < bestEnd ||
               (slot.fin == bestEnd &&
                Math.abs(slot.debut - tf.WP.debut) <
                Math.abs(bestSol == null ? 1e99 : bestSol.debut - tf.WP.debut))) {

                bestEnd = slot.fin;
                bestMac = mc.ID;
                bestSol = slot;
            }
        }

   /* ===================== Auctioneer.runAuctions() ===================== */
if (bestMac != null && bestSol != null) {       // ← AJOUT
    win.put(tf.ID,
        new AbstractMap.SimpleEntry<>(bestMac, bestSol));
    shadow.get(bestMac).add_TF(tf, bestSol);    // réservation
}                                               // sinon : on laissera

    }
}

/* ====================================================================
 *  travelTime : durée totale du trajet entre deux sites logistiques
 *               (0 si même site).
 * ==================================================================== */
private double travelTime(String from, String to) {
    if (from == null || from.isEmpty() || from.equals(to)) return 0.0;

    LinkedList<TacheTransport> segs =
        SCEMPT_Algo.instance.pathfinder
                      .genererTachesTransport(from, to, 0, "calc");

    double sum = 0.0;
    for (TacheTransport tt : segs) sum += tt.duree;
    return sum;
}

/* ======================================================================
 *  travelTime : durée totale du trajet entre deux sites logistiques.
 *               (0 si sites identiques)
 * ====================================================================== */



    /* ---------------------- accès résultat -------------------------- */
    public Identifiant winnerMachine(Identifiant tfID) {
        Map.Entry<Identifiant, Interval> e = win.get(tfID);
        return e == null ? null : e.getKey();
    }
    public Interval winnerSlot(Identifiant tfID) {
        Map.Entry<Identifiant, Interval> e = win.get(tfID);
        return e == null ? null : e.getValue();
    }
}

