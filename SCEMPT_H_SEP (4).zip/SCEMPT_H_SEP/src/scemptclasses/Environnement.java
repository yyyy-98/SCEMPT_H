package scemptclasses;
import java.util.*;

public class Environnement {

    public LinkedList<Objet> liste_TF = new LinkedList<>();
    public LinkedList<Objet> liste_TM = new LinkedList<>();
    public LinkedList<Objet> liste_TT = new LinkedList<>();

    public void initialise() {
        for (Objet o : liste_TF) {
            if (!o.is_fixed()) {
                o.Prop.clear();
            }
        }
        for (Objet o : liste_TM) {
            if (!o.is_fixed()) {
                o.Prop.clear();
            }
        }
        for (Objet o : liste_TT) {
            if (!o.is_fixed()) {
                o.Prop.clear();
            }
        }
    }
  public boolean resourceDisponible(Identifiant res, Interval I) {
    // TF fixées
    for (Objet o : liste_TF)
        if (o.FP != null && o.FP.ID_resource.equals(res)
                && o.FP.creneau.debut < I.fin && I.debut < o.FP.creneau.fin)
            return false;

    // TM fixées : (1) côté mainteneur, (2) côté machine entretenue
    for (Objet o : liste_TM) {
        if (o.FP == null) continue;
        Interval c = o.FP.creneau;
        if (c.debut < I.fin && I.debut < c.fin) {
            if (o.FP.ID_resource.equals(res)) return false; // mainteneur occupé
            if ("M".equals(res.type) && o.TM != null && res.equals(o.TM.ID_Machine))
                return false; // machine indispo pendant sa TM
        }
    }
    // TT fixées
    for (Objet o : liste_TT)
        if (o.FP != null && o.FP.ID_resource.equals(res)
                && o.FP.creneau.debut < I.fin && I.debut < o.FP.creneau.fin)
            return false;

    return true;
}

    /**
     * Retourne l’Objet (TF/TM/TT) dont l’identifiant est id, ou null si
     * introuvable.
     */
    public Objet getObjetParID(Identifiant id) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(id)) {
                return o;
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(id)) {
                return o;
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(id)) {
                return o;
            }
        }
        return null;
    }

    // === Environnement.java — remplacez add_TF(...) ===
public void add_TF(TacheProduction tf, Interval wp) {

    // Si la TF existe déjà : on met à jour la fenêtre technique (WP),
    // mais l'affichage reste la WP_fixed.
    for (Objet o : liste_TF) {
        if (o.TF.ID_ordre.equals(tf.ID_ordre) && o.TF.ID_tache.equals(tf.ID_tache)) {
            o.TF.R  = tf.R;
            o.TF.D  = tf.D;
            o.TF.WP = wp;
            o.WP    = (tf.WP_fixed != null ? tf.WP_fixed : wp);
            return;
        }
    }

    // Sinon, insertion
    tf.ID = new Identifiant("TF", liste_TF.size());
    Objet O = new Objet(tf.ID, (tf.WP_fixed != null ? tf.WP_fixed : wp)); // affichage = WP objectif
    O.TF = tf;
    liste_TF.add(O);
}

    public void add_TM(TacheMaintenance tm) {
        tm.ID = new Identifiant("TM", liste_TM.size());
        Objet O = new Objet(tm.ID, new Interval(tm.R, tm.R + tm.duree));
        O.TM = tm;
        liste_TM.add(O);
    }

    public void add_TT(TacheTransport tt) {
        tt.ID = new Identifiant("TT", liste_TT.size());
        Objet O = new Objet(tt.ID, new Interval(tt.R, tt.R + tt.duree));
        O.TT = tt;
        liste_TT.add(O);
    }

    public boolean is_Fixed(Identifiant ID) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(ID)) {
                return o.is_fixed();
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(ID)) {
                return o.is_fixed();
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(ID)) {
                return o.is_fixed();
            }
        }
        return false;
    }

    public Interval get_WP(Identifiant ID) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(ID)) {
                return o.WP;
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(ID)) {
                return o.WP;
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(ID)) {
                return o.WP;
            }
        }
        return null;
    }

    public LinkedList<Proposition> get_Proposition(Identifiant ID) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(ID)) {
                return o.Prop;
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(ID)) {
                return o.Prop;
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(ID)) {
                return o.Prop;
            }
        }
        return new LinkedList<>();
    }

    public void add_Proposition(Proposition p) {
        if (p.ID_tache.type.equals("TF")) {
            for (Objet o : liste_TF) {
                if (o.ID.equals(p.ID_tache)) {
                    o.Prop.add(p);
                }
            }
        } else if (p.ID_tache.type.equals("TM")) {
            for (Objet o : liste_TM) {
                if (o.ID.equals(p.ID_tache)) {
                    o.Prop.add(p);
                }
            }
        } else {
            for (Objet o : liste_TT) {
                if (o.ID.equals(p.ID_tache)) {
                    o.Prop.add(p);
                }
            }
        }
    }

    public void set_Final(Identifiant ID, Position pos) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(ID)) {
                o.FP = pos;
                o.Prop.clear();
                return;
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(ID)) {
                o.FP = pos;
                o.Prop.clear();
                return;
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(ID)) {
                o.FP = pos;
                o.Prop.clear();
                return;
            }
        }
    }

    public Position get_Final(Identifiant ID) {
        for (Objet o : liste_TF) {
            if (o.ID.equals(ID)) {
                return o.FP;
            }
        }
        for (Objet o : liste_TM) {
            if (o.ID.equals(ID)) {
                return o.FP;
            }
        }
        for (Objet o : liste_TT) {
            if (o.ID.equals(ID)) {
                return o.FP;
            }
        }
        return null;
    }

    public void supprimer_objet(Identifiant ID) {
        Iterator<Objet> it = liste_TF.iterator();
        while (it.hasNext()) {
            Objet o = it.next();
            if (o.ID.equals(ID)) {
                it.remove();
                return;
            }
        }
        it = liste_TM.iterator();
        while (it.hasNext()) {
            Objet o = it.next();
            if (o.ID.equals(ID)) {
                it.remove();
                return;
            }
        }
        it = liste_TT.iterator();
        while (it.hasNext()) {
            Objet o = it.next();
            if (o.ID.equals(ID)) {
                it.remove();
                return;
            }
        }
    }

    public boolean EOTF() {
        for (Objet o : liste_TF) {
            if (!o.is_fixed()) {
                return false;
            }
        }
        return true;
    }

    public boolean EOTM() {
        for (Objet o : liste_TM) {
            if (!o.is_fixed()) {
                return false;
            }
        }
        return true;
    }

    public boolean EOTT() {
        for (Objet o : liste_TT) {
            if (!o.is_fixed()) {
                return false;
            }
        }
        return true;
    }

    public double n_TF_non_validee() {
        double c = 0;
        for (Objet o : liste_TF) {
            if (!o.is_fixed()) {
                c++;
            }
        }
        return c;
    }

    public double n_TM() {
        return liste_TM.size();
    }

    public double n_TT() {
        return liste_TT.size();
    }

  @Override
public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("ID\tWP\tProp\tFP\n");

    // ——— TF ———
    sb.append("list TF\n");
    for (Objet o : liste_TF) {
        String ofId = o.TF.ID_ordre.toString();
        String tfId = o.TF.ID_tache.toString();
        sb.append(ofId).append(", ").append(tfId).append("\t");
        sb.append(o.WP != null ? o.WP : "-").append("\t");

        if (!o.Prop.isEmpty()) {
            Iterator<Proposition> it = o.Prop.iterator();
            Proposition p0 = it.next();
            sb.append(p0).append("\t-\n");
            while (it.hasNext()) sb.append("\t\t").append(it.next()).append("\n");
        } else {
            sb.append("-\t").append(o.FP != null ? o.FP : "-").append("\n");
        }
    }

    // ——— TM ———
    sb.append("list TM\n");
    for (Objet o : liste_TM) {
        // ID, Machine, Composant
        sb.append(o.ID).append(", Mach=").append(o.TM.ID_Machine)
          .append(", Comp=").append(o.TM.ID_Composant).append("\t");
        sb.append(o.WP != null ? o.WP : "-").append("\t");
        if (!o.Prop.isEmpty()) {
            Iterator<Proposition> it = o.Prop.iterator();
            Proposition p0 = it.next();
            sb.append(p0).append("\t-\n");
            while (it.hasNext()) sb.append("\t\t").append(it.next()).append("\n");
        } else {
            sb.append("-\t").append(o.FP != null ? o.FP : "-").append("\n");
        }
    }

    // ——— TT ———
    sb.append("list TT\n");
    for (Objet o : liste_TT) {
        sb.append(o.ID).append(",").append(o.TT.origine).append("->").append(o.TT.destination);
        if (o.TT.reason != null) sb.append(" reason=").append(o.TT.reason);
        sb.append("\t").append(o.WP != null ? o.WP : "-").append("\t");
        if (!o.Prop.isEmpty()) {
            Iterator<Proposition> it = o.Prop.iterator();
            Proposition p0 = it.next();
            sb.append(p0).append("\t-\n");
            while (it.hasNext()) sb.append("\t\t").append(it.next()).append("\n");
        } else {
            sb.append("-\t").append(o.FP != null ? o.FP : "-").append("\n");
        }
    }
    return sb.toString();
}

}
