package scemptclasses;


import java.util.*;


public class Identifiant {

    public String type;
    public int ordre;

    public Identifiant(String t, int o) {
        this.type = t;
        this.ordre = o;
    }


    @Override
    public String toString() {
        return type + ordre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Identifiant)) {
            return false;
        }
        Identifiant that = (Identifiant) o;
        return this.type.equals(that.type) && this.ordre == that.ordre;
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, ordre);
    }
}
