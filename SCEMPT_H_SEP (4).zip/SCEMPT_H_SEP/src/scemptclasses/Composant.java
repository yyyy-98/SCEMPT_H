package scemptclasses;

import java.util.*;

/**
 * **************************************************
 *                    Composant
 * **************************************************
 */
public class Composant {

    public Identifiant ID;
    public Identifiant type;
    public double lambda;
    public double sigma;
    public static final double PI = 3.14159265358979;
    Random randomGen = new Random();

    public double seuil;
    public double temps_reparation = 12;

    public double temps_marche = 0.0;
    public double nextDueDate  = 0.0;

    public boolean PHM;
    public LinkedList<Position> planning = new LinkedList<>();

    public Composant(Identifiant id, Identifiant tp, double lambda, double sigma, boolean phm) {
        this.ID = id; this.type = tp; this.sigma = sigma;
        this.randomGen = new Random(System.nanoTime());
        this.lambda = Math.max(0.0, lambda + randomGen.nextGaussian() * sigma);
        this.seuil  = Math.max(0.0, SCEMPT_Algo.PHM_SEUIL_FACTOR * this.lambda);
        this.PHM    = phm;
        refreshNextDueDate();
    }
    public Composant(Composant c) {
        this.ID = c.ID; this.type = c.type; this.sigma = c.sigma;
        this.randomGen = new Random(System.nanoTime());
        this.lambda = c.lambda;
        this.seuil  = (c.seuil > 0.0 ? c.seuil : Math.max(0.0, SCEMPT_Algo.PHM_SEUIL_FACTOR * this.lambda));
        this.temps_reparation = c.temps_reparation;
        this.temps_marche     = c.temps_marche;
        this.PHM = c.PHM; refreshNextDueDate();
    }

    /* ——— état & seuils ——— */
    public void consume(double dur) { temps_marche += dur; refreshNextDueDate(); }
    public void resetAfterMaintenance() { temps_marche = 0.0; refreshNextDueDate(); }
    public double remainingLife() { return lambda - temps_marche; }
    public boolean willFail(double dur) { return temps_marche + dur >= lambda; }
    public double RUL() { return lambda - temps_marche; }
    public void refreshNextDueDate() { nextDueDate = temps_marche + lambda; }
    public boolean willCrossThreshold(double dur) { return (temps_marche + dur) >= (seuil - 1e-9); }

    /* ——— planning local ——— */
    public void add_to_planning(Position pos) { planning.add(pos); trier_planning(); }
    public void remove_from_planning(Identifiant tid) { planning.removeIf(p -> p.ID_tache.equals(tid)); }
    private void trier_planning() {
        Position[] arr = planning.toArray(new Position[0]);
        for (int i=0;i<arr.length-1;i++){ int min=i; for (int j=i+1;j<arr.length;j++) if (arr[j].creneau.debut < arr[min].creneau.debut) min=j; if (min!=i){ Position t=arr[min]; arr[min]=arr[i]; arr[i]=t; } }
        planning.clear(); planning.addAll(Arrays.asList(arr));
    }

    public Position get_maintenance_avant(double t) {
        Position ret=null; for (Position p : planning) if (p.ID_tache.type.equals("TM") && p.creneau.fin <= t) ret=p; return ret;
    }
    public Position get_maintenance_apres(double t) {
        for (Position p : planning) if (p.ID_tache.type.equals("TM") && p.creneau.debut >= t) return p; return null;
    }
    public double taux_utilisation(double t1, double t2) {
        double sum=0; for (Position p : planning){ double deb = Math.max(t1, p.creneau.debut); double fin = Math.min(t2, p.creneau.fin); if (fin>deb) sum += (fin-deb); } return sum;
    }

    /** Proba de panne sur H en tenant compte de l’historique/planning présent. */
    public double proba_fail_over_horizon(Interval H) {
        if (H == null || H.getTaille() <= 0) return 0.0;
        return Math.max(0.0, Math.min(1.0, proba_panne(H)));
    }

    /** Proba de panne sur H pour un composant “neuf” au début de H. */
    public double proba_fail_over_horizon_as_new(Interval H) {
        if (H == null || H.getTaille() <= 0) return 0.0;
        double horizon = H.getTaille();
        double mu = lambda;
        double sg = (PHM ? sigma/5.0 : sigma);
        // CDF normale ~ N(mu, sg) entre [-100 ; horizon]
        double cdf1 = 0.5 * (1.0 + erf((-100.0 - mu) / (sg * Math.sqrt(2.0))));
        double cdf2 = 0.5 * (1.0 + erf((horizon - mu) / (sg * Math.sqrt(2.0))));
        double p = cdf2 - cdf1;
        if (Double.isNaN(p)) p = 0.0;
        return Math.max(0.0, Math.min(1.0, p));
    }

    /* ——— proba_panne existante (gardée) ——— */
    public double proba_panne(Interval I) {
        double TM_avant = 0, TM_apres = Double.POSITIVE_INFINITY;
        Position pm1 = get_maintenance_avant(I.debut); if (pm1 != null) TM_avant = pm1.creneau.fin;
        Position pm2 = get_maintenance_apres(I.fin);   if (pm2 != null) TM_apres = pm2.creneau.debut;
        double taux = taux_utilisation(TM_avant, TM_apres) + I.getTaille();
        double l, sg; if (PHM) { l = tirage_aleatoire_loi_normale(0, 60, lambda, sigma); sg = sigma/5.0; } else { l = lambda; sg = sigma; }
        if (Double.isInfinite(taux)) return 1.0; if (Double.isNaN(taux)) return 0.0;
        double z1 = (-100.0 - l) / sg, z2 = (taux - l) / sg;
        double cdf1 = 0.5 * (1.0 + erf(z1 / Math.sqrt(2.0))), cdf2 = 0.5 * (1.0 + erf(z2 / Math.sqrt(2.0)));
        double p = cdf2 - cdf1; if (p < 0) p = 0; if (p > 1) p = 1; return p;
    }

    public static double erf(double x) {
        double a1=0.254829592,a2=-0.284496736,a3=1.421413741,a4=-1.453152027,a5=1.061405429,p=0.3275911;
        int sign = x < 0 ? -1 : 1; x = Math.abs(x); double t = 1.0/(1.0 + p*x);
        double y = 1.0 - ((((a5*t + a4)*t + a3)*t + a2)*t + a1)*t*Math.exp(-x*x);
        return sign * y;
    }
    public int tirage_aleatoire_loi_normale(int xmin, int xmax, double lam, double s) {
        if (s <= 1e-9) return (int)Math.round(Math.max(xmin, Math.min(xmax, lam)));
        double x = lam + randomGen.nextGaussian() * s;
        return (int)Math.max(xmin, Math.min(xmax, Math.round(x)));
    }
}
